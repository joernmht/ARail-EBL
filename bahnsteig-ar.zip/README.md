# Bahnsteig-AR

Augmented Reality für die Modellbahn: Zwei Bahnsteige werden über ArUco-Marker erkannt, darauf laufen simulierte Fahrgäste. Ihre Zahl steigt und sinkt, sie steigen in eingeblendete Züge ein und aus, und ihre Farbe zeigt die Stimmung: **grün = gute Laune, rot = schlechte Laune**.

Es gibt zwei Versionen mit derselben Rechnung:

- **PC** (`bahnsteig_ar.py`): Python + OpenCV, live mit Webcam.
- **Handy/Browser** (`web/`): statische Web-Seite, live mit Handykamera (über https), per Foto oder Video.

![Überlagerung auf der echten Anlage](docs/ueberlagerung_foto.jpg)

## Aufbau der Anlage

| | |
|---|---|
| Marker | **Original ArUco** (`DICT_ARUCO_ORIGINAL`), 30 × 30 mm (schwarzes Quadrat, ohne weißen Rand gemessen), mit weißem Rand drumherum |
| Bahnsteig 1 | zwischen **Marker-ID 0 und 1** |
| Bahnsteig 2 | zwischen **Marker-ID 2 und 3** |
| IDs 4–7 | optional; flach auf der Anlage helfen sie beim Verfolgen, wenn ein Bahnsteigmarker verdeckt ist, und bei der Brennweitenschätzung |

Die Marker liegen flach und dürfen beliebig gedreht sein. Beide Marker eines Bahnsteigs müssen einmal gleichzeitig im Bild sein; danach genügt einer (oder andere Marker der Anlage).

Aus einem Foto der Anlage gemessen (30.09.2026) und so voreingestellt:

| Bahnsteig | Marker | Länge | Breite | Lage der Marker |
|---|---|---|---|---|
| 1 | 0 – 1 | ca. 700 mm | **70 mm** | mittig (±4 mm) |
| 2 | 2 – 3 | ca. 720 mm | **37 mm** | mittig (±4 mm) |

Maßstab: H0 (1:87).

## PC-Version

```bash
pip install -r requirements.txt
python bahnsteig_ar.py              # Webcam 0
python bahnsteig_ar.py --kamera 1   # andere Kamera
python bahnsteig_ar.py --kamera film.mp4 --ausgabe ergebnis.mp4
```

| Taste | Wirkung |
|---|---|
| 1 / 2 | Zug fährt in Bahnsteig 1 / 2 ein |
| V | Verspätung an/aus (keine Züge, Stimmung kippt ins Rote) |
| + / − | mehr / weniger Andrang |
| S / I / M | Laufspuren / Infoschilder / Markerumrisse an/aus |
| , / . | Brennweite kleiner/größer (falls Figuren schief stehen) |
| R | Bahnsteige leeren |
| F | Vollbild |
| Leertaste | Pause |
| Q / Esc | Beenden |

Wörterbuch automatisch suchen lassen: `--woerterbuch auto`.

## Handy / Browser

`web/` ist eine statische Seite (`index.html`, `kern.js`, `beispiel.jpg`); die Markererkennung [js-aruco2](https://github.com/damianofalcioni/js-aruco2) wird vom CDN jsdelivr geladen.

**Live-Kamera auf dem Handy** braucht eine https-Adresse. Am einfachsten über GitHub Pages:

1. Repo auf GitHub pushen.
2. *Settings → Pages → Build and deployment → Source: GitHub Actions* wählen.
3. Der Workflow `.github/workflows/pages.yml` veröffentlicht `web/` bei jedem Push auf `main`.
4. Die Pages-Adresse auf dem Handy öffnen, „Live-Kamera“ tippen, Zugriff erlauben.

Ohne https bleiben „Foto aufnehmen“ und „Video aufnehmen“ (öffnen die Handykamera, die Auswertung läuft danach). Am PC geht die Kamera auch lokal:

```bash
cd web && python -m http.server 8000     # dann http://localhost:8000
```

Eine einzelne HTML-Datei (z. B. zum Verschicken): `python werkzeuge/einzeldatei.py` → `dist/bahnsteig_ar.html`.

## Einstellungen

- **PC:** oben in `bahnsteig_ar.py` – `MARKER_GROESSE_MM`, `WOERTERBUCH`, `MASSSTAB`, `BAHNSTEIGE` (je Bahnsteig `breite_mm`, `versatz_mm` = seitliche Verschiebung, `ueberstand_mm` = Verlängerung über die Markermitten, `gleis` = `"links"`/`"rechts"`/`"beide"`), dazu `ZEITRAFFER`, `GRUNDANDRANG`, `ZUGTAKT_S`, `HALTEZEIT_ZUG_S`, `ZUG_ZEICHNEN`.
- **Web:** `EINST` oben in `web/kern.js` (gleiche Bedeutung); Maßstab, Breiten, Markergröße und Wörterbuch auch im Menü „Einstellungen und Tipps“.

## Wie es ohne Kalibrierboard funktioniert

- **Bahnsteigfläche:** Jeder Marker liefert eine Homographie (Marker-mm → Bildpixel). Den Abstand zweier Marker ergibt die Perspektive entlang ihrer Verbindungslinie: *Abstand = Pixelabstand / √(Maßstab bei A · Maßstab bei B)*. Dafür werden keine Kameradaten gebraucht, und es zählen nur die gut bestimmten lokalen Maßstäbe der Marker.
- **Verdeckte Marker:** Die Bahnsteigecken werden über die Bildbewegung aller übrigen sichtbaren Marker weitergeführt.
- **Brennweite** (nur für die senkrecht stehenden Figuren nötig): aus einer gemeinsamen Homographie aller sichtbaren Marker geschätzt (lange Basis statt 30 mm).
- **Kalibrierung (optional)** mit `kalibrierung.py`: jeder einzelne Marker dient als Kalibrierziel, kein Board nötig. Lohnt sich bei Weitwinkel-Webcams mit gebogenen Kanten. Ergebnis `kamera_kalibrierung.npz` wird automatisch geladen (gilt nur für diese Kamera und Auflösung).

## Tests

```bash
pip install -r requirements-dev.txt
python -m pytest tests                  # Python: Tracking-Szene, Kalibrierung

npm install
python tests/web/erzeuge_testdaten.py   # Testbilder für die Web-Tests
npm test                                # Web: Wörterbücher, JS-Kern, Seite
```

Geprüft wird an einer synthetischen H0-Szene mit bekannter Kamera (f = 950 px), Original-ArUco-Markern, 70/37 mm breiten Bahnsteigen und zeitweise verdeckten Markern:

- Bahnsteigecken im Median < 3 px, maximal < 6 px genau
- Bahnsteiglänge auf 3–5 % genau
- Brennweite auf 10 % genau
- js-aruco2 liefert für alle sieben unterstützten Wörterbücher dieselben IDs wie OpenCV
- die Web-Seite startet und erkennt das Beispielbild (Browser nachgebildet)

## Projektstruktur

```
bahnsteig_ar.py            PC-Version (Erkennung, Geometrie, Simulation, Anzeige)
kalibrierung.py            optionale Kamerakalibrierung mit den Markern
web/index.html             Handy-/Browser-Seite
web/kern.js                Logik der Web-Version (Portierung von bahnsteig_ar.py)
web/beispiel.jpg           Beispielbild (synthetisch)
werkzeuge/beispielbild.py  erzeugt web/beispiel.jpg
werkzeuge/einzeldatei.py   baut dist/bahnsteig_ar.html (alles in einer Datei)
tests/                     Python-Tests + synthetische Szene
tests/web/                 Web-Tests (Node) + Testdaten-Generator
docs/                      Bilder für dieses README
.github/workflows/         Veröffentlichung von web/ über GitHub Pages
```

Eigene Fotos und Videos der Anlage am besten in einen Ordner `daten/`. Videos über 50 MB lieber mit Git LFS oder gar nicht einchecken.

## Stand und offene Punkte

- Getestet mit der synthetischen Szene und einem echten Foto der Anlage. **Live mit Webcam oder Handykamera ist noch nicht getestet.**
- Die Web-Version kennt keine Linsenkorrektur. Die Markererkennung im Browser (js-aruco2) braucht etwas größere Marker als OpenCV (ab etwa 25 px Kantenlänge); Fotos werden deshalb in voller Auflösung durchsucht.
- Die Fahrgäste sind simuliert. Für echte Zahlen müsste ein Datenformat festgelegt werden (z. B. CSV mit Zeit, Bahnsteig, Personen, Stimmung).
- Lizenz für dieses Repo: noch festzulegen.

## Fremdkomponenten

- [OpenCV](https://opencv.org) (Apache 2.0) und NumPy (BSD) – über pip
- [js-aruco2](https://github.com/damianofalcioni/js-aruco2) 2.0.0 (MIT); die Wörterbücher stammen aus OpenCV (BSD 3-Clause). Wird zur Laufzeit von jsdelivr geladen und für die Tests per npm installiert.
