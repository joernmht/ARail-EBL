"""Baut web/index.html, web/kern.js und web/beispiel.jpg zu EINER HTML-Datei zusammen
(zum Verschicken oder fuer Hoster, die nur eine Datei annehmen).
Aufruf: python werkzeuge/einzeldatei.py  ->  dist/bahnsteig_ar.html"""
import base64
import os

HIER = os.path.dirname(os.path.abspath(__file__))
WEB = os.path.join(HIER, "..", "web")
DIST = os.path.join(HIER, "..", "dist")

if __name__ == "__main__":
    html = open(os.path.join(WEB, "index.html"), encoding="utf-8").read()
    kern = open(os.path.join(WEB, "kern.js"), encoding="utf-8").read()
    bild = base64.b64encode(open(os.path.join(WEB, "beispiel.jpg"), "rb").read()).decode()
    alt_kern, alt_bild = '<script src="kern.js"></script>', 'const BEISPIEL = "beispiel.jpg";'
    assert alt_kern in html and alt_bild in html, "index.html hat nicht die erwartete Form"
    html = html.replace(alt_kern, "<script>\n" + kern + "\n</script>")
    html = html.replace(alt_bild, f'const BEISPIEL = "data:image/jpeg;base64,{bild}";')
    os.makedirs(DIST, exist_ok=True)
    ziel = os.path.join(DIST, "bahnsteig_ar.html")
    open(ziel, "w", encoding="utf-8").write(html)
    print("geschrieben:", os.path.normpath(ziel), os.path.getsize(ziel) // 1024, "KB")
