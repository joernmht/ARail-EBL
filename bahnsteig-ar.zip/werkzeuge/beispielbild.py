"""Erzeugt web/beispiel.jpg: synthetische H0-Anlage mit Original-ArUco-Markern 0-7
und Bahnsteigen von 70 mm und 37 mm Breite (wie auf der echten Anlage)."""
import os
import sys

import cv2

HIER = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HIER, "..", "tests"))
import szene  # noqa: E402

if __name__ == "__main__":
    bild, _ = szene.render(szene.textur(), 12)
    ziel = os.path.join(HIER, "..", "web", "beispiel.jpg")
    cv2.imwrite(ziel, bild, [cv2.IMWRITE_JPEG_QUALITY, 80, cv2.IMWRITE_JPEG_OPTIMIZE, 1])
    print("geschrieben:", os.path.normpath(ziel), os.path.getsize(ziel) // 1024, "KB")
