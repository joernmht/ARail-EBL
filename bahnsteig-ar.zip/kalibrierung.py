#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Kamerakalibrierung nur mit den ArUco-Markern - kein Kalibrierboard noetig
=========================================================================

Jeder einzelne 30-mm-Marker dient als kleines Kalibrierziel. Die Marker muessen
nicht ausgemessen oder in einem Raster angeordnet werden.

Wofuer?  bahnsteig_ar.py laeuft auch ohne Kalibrierung. Die Kalibrierung lohnt
sich, wenn die Webcam ein Weitwinkel mit sichtbarer Verzeichnung hat (gerade
Kanten am Bildrand sind gebogen) oder die Figuren am Bildrand schief stehen.

Ablauf
  1. python kalibrierung.py            (gleiche Kamera/Aufloesung wie spaeter)
  2. Einen oder mehrere Marker (am besten flach auf einer Pappe) vor der Kamera
     bewegen - oder die Kamera ueber die Anlage fuehren:
       - moeglichst SCHRAEG (30-60 Grad gekippt), aus verschiedenen Richtungen
       - auch an den Bildraendern und in den Ecken
       - Marker gross genug im Bild (mind. ca. 40 Pixel)
     Leertaste = Aufnahme, A = automatische Aufnahme an/aus
  3. Ab 40 Markeransichten: C = berechnen und speichern
     -> kamera_kalibrierung.npz (wird von bahnsteig_ar.py automatisch geladen)
  Q = Beenden

Die Punkte im Bild zeigen, wo schon Ansichten gesammelt wurden - das ganze
Bild sollte grob abgedeckt sein.
"""

import argparse
import time

import cv2
import numpy as np

from bahnsteig_ar import (KALIBRIERDATEI, MARKER_ECKEN_MM, WOERTERBUCH, MarkerErkennung,
                          kamera_oeffnen, textkasten)

MIN_ANSICHTEN = 40
MIN_KANTE_PX = 35


def objektpunkte():
    p = np.zeros((4, 3), np.float32)
    p[:, :2] = MARKER_ECKEN_MM
    return p


def berechne(bildpunkte, groesse):
    """bildpunkte: Liste von 4x2-Arrays (je eine Markeransicht). -> (rms, K, dist)"""
    w, h = groesse
    K0 = np.array([[0.8 * w, 0, w / 2.0], [0, 0.8 * w, h / 2.0], [0, 0, 1.0]])
    flags = (cv2.CALIB_USE_INTRINSIC_GUESS | cv2.CALIB_FIX_PRINCIPAL_POINT |
             cv2.CALIB_FIX_ASPECT_RATIO | cv2.CALIB_ZERO_TANGENT_DIST | cv2.CALIB_FIX_K3)
    obj = [objektpunkte() for _ in bildpunkte]
    img = [np.asarray(b, np.float32).reshape(-1, 1, 2) for b in bildpunkte]
    kriterien = (cv2.TERM_CRITERIA_COUNT + cv2.TERM_CRITERIA_EPS, 200, 1e-9)
    rms, K, dist, _, _ = cv2.calibrateCamera(obj, img, (w, h), K0, np.zeros(5), flags=flags,
                                             criteria=kriterien)
    return rms, K, dist.ravel()


def merkmal(ecken, w, h):
    """Grobe Beschreibung einer Ansicht (Ort + Perspektive), um Doppelte zu vermeiden."""
    m = ecken.mean(0)
    kanten = np.linalg.norm(np.roll(ecken, -1, 0) - ecken, axis=1)
    return np.array([m[0] / w, m[1] / h,
                     (kanten[0] - kanten[2]) / kanten.mean(),
                     (kanten[1] - kanten[3]) / kanten.mean()])


def main():
    ap = argparse.ArgumentParser(description="Kamerakalibrierung mit ArUco-Markern")
    ap.add_argument("--kamera", default="0")
    ap.add_argument("--breite", type=int, default=1280)
    ap.add_argument("--hoehe", type=int, default=720)
    ap.add_argument("--woerterbuch", default=WOERTERBUCH, help="oder auto")
    ap.add_argument("--ausgabe", default=KALIBRIERDATEI)
    args = ap.parse_args()

    quelle = int(args.kamera) if args.kamera.isdigit() else args.kamera
    cap = kamera_oeffnen(quelle, args.breite, args.hoehe)
    ok, bild = cap.read()
    if not ok:
        raise SystemExit("Keine Bilder von der Kamera.")
    h, w = bild.shape[:2]
    erk = MarkerErkennung(None if args.woerterbuch.lower() == "auto" else args.woerterbuch)
    ansichten, merkmale = [], []
    auto = False
    t_auto = 0.0
    meldung = ""
    cv2.namedWindow("Kalibrierung", cv2.WINDOW_NORMAL)

    while ok:
        grau = cv2.cvtColor(bild, cv2.COLOR_BGR2GRAY)
        ecken = erk.erkenne(grau)
        aus = bild.copy()
        brauchbar = {}
        for mid, c in ecken.items():
            kante = np.linalg.norm(np.roll(c, -1, 0) - c, axis=1).min()
            gut = kante >= MIN_KANTE_PX
            cv2.polylines(aus, [c.astype(np.int32)], True, (0, 255, 0) if gut else (0, 0, 255), 2)
            if gut:
                brauchbar[mid] = c
        for m in merkmale:
            cv2.circle(aus, (int(m[0] * w), int(m[1] * h)), 4, (255, 200, 0), -1)

        def aufnehmen(nur_neue):
            n = 0
            for c in brauchbar.values():
                mk = merkmal(c, w, h)
                if nur_neue and merkmale and np.min(np.linalg.norm(np.array(merkmale) - mk, axis=1)) < 0.08:
                    continue
                ansichten.append(c.copy())
                merkmale.append(mk)
                n += 1
            return n

        if auto and time.time() - t_auto > 0.4 and brauchbar:
            if aufnehmen(True):
                t_auto = time.time()

        zeilen = [f"Woerterbuch: {erk.name or 'suche ...'}",
                  f"Ansichten: {len(ansichten)} (mind. {MIN_ANSICHTEN})",
                  "Leertaste Aufnahme   A Automatik " + ("AN" if auto else "aus") + "   C Berechnen   Q Ende",
                  "Marker schräg halten, auch an den Bildrändern!"]
        if meldung:
            zeilen.append(meldung)
        textkasten(aus, 10, 10, zeilen)
        cv2.imshow("Kalibrierung", aus)
        k = cv2.waitKey(1) & 0xFF
        if k in (ord("q"), 27):
            break
        if k == ord(" "):
            meldung = f"{aufnehmen(False)} Ansicht(en) aufgenommen"
        elif k == ord("a"):
            auto = not auto
        elif k == ord("c"):
            if len(ansichten) < MIN_ANSICHTEN:
                meldung = f"Noch zu wenig Ansichten ({len(ansichten)}/{MIN_ANSICHTEN})"
            else:
                rms, K, dist = berechne(ansichten, (w, h))
                np.savez(args.ausgabe, K=K, dist=dist, bildgroesse=np.array([w, h]), rms=rms)
                meldung = f"Gespeichert: f = {K[0, 0]:.0f} px, k1 = {dist[0]:.3f}, Fehler {rms:.2f} px"
                print(meldung, "->", args.ausgabe)
                if rms > 1.0:
                    meldung += "  (hoch - mehr schräge Ansichten sammeln)"
        ok, bild = cap.read()
    cap.release()
    cv2.destroyAllWindows()


if __name__ == "__main__":
    main()
