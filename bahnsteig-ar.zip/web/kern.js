/* Bahnsteig-AR – Kernlogik (Browser). Portierung von bahnsteig_ar.py.
   Benoetigt js-aruco2 (globale Objekte AR und CV). */
"use strict";

const EINST = {
  markerMM: 30,            // Kantenlaenge des schwarzen Marker-Quadrats
  woerterbuch: "ARUCO",    // Original ArUco; "" = automatisch suchen
  massstab: 87,            // H0 = 87, TT = 120, N = 160
  zeitraffer: 2,
  grundandrang: 0.5,       // Fahrgaeste pro Sekunde auf 25 m Bahnsteig (Vorbild)
  maxPersonen: 140,
  zugtakt: [50, 90],       // Simulationssekunden
  haltezeit: 24,
  haltenS: 1.5,            // Einblendung bleibt so lange, wenn alle Marker verdeckt sind
  eckenEinzug: 1.0,        // px, fuer den zweiten Dekodierversuch (siehe Erkennung)
  bahnsteige: [
    { name: "Bahnsteig 1", marker: [0, 1], breite: 70, versatz: 0, ueberstand: 0, gleis: "beide" },
    { name: "Bahnsteig 2", marker: [2, 3], breite: 37, versatz: 0, ueberstand: 0, gleis: "beide" },
  ],
};

/* ---------------- Lineare Algebra (3x3 zeilenweise als Array[9]) ---------------- */
function loese(A, b) {                       // Gauss mit Pivotsuche, A n x n (Array von Arrays)
  const n = b.length, M = A.map((r, i) => r.concat([b[i]]));
  for (let c = 0; c < n; c++) {
    let p = c;
    for (let r = c + 1; r < n; r++) if (Math.abs(M[r][c]) > Math.abs(M[p][c])) p = r;
    if (Math.abs(M[p][c]) < 1e-12) return null;
    [M[c], M[p]] = [M[p], M[c]];
    for (let r = 0; r < n; r++) {
      if (r === c) continue;
      const f = M[r][c] / M[c][c];
      for (let k = c; k <= n; k++) M[r][k] -= f * M[c][k];
    }
  }
  return M.map((r, i) => r[n] / r[i]);
}
function mul3(A, B) {
  const C = new Array(9);
  for (let i = 0; i < 3; i++) for (let j = 0; j < 3; j++)
    C[i * 3 + j] = A[i * 3] * B[j] + A[i * 3 + 1] * B[3 + j] + A[i * 3 + 2] * B[6 + j];
  return C;
}
function inv3(m) {
  const [a, b, c, d, e, f, g, h, i] = m;
  const A = e * i - f * h, B = -(d * i - f * g), C = d * h - e * g;
  const det = a * A + b * B + c * C;
  if (Math.abs(det) < 1e-15) return null;
  return [A / det, -(b * i - c * h) / det, (b * f - c * e) / det,
          B / det, (a * i - c * g) / det, -(a * f - c * d) / det,
          C / det, -(a * h - b * g) / det, (a * e - b * d) / det];
}
function anwenden(H, p) {
  const w = H[6] * p[0] + H[7] * p[1] + H[8];
  return [(H[0] * p[0] + H[1] * p[1] + H[2]) / w, (H[3] * p[0] + H[4] * p[1] + H[5]) / w];
}
function homographie(von, nach) {            // exakt aus 4 Punktpaaren
  const A = [], b = [];
  for (let k = 0; k < 4; k++) {
    const [x, y] = von[k], [u, v] = nach[k];
    A.push([x, y, 1, 0, 0, 0, -u * x, -u * y]); b.push(u);
    A.push([0, 0, 0, x, y, 1, -v * x, -v * y]); b.push(v);
  }
  const h = loese(A, b);
  return h ? h.concat([1]) : null;
}
function normierung(P) {
  let mx = 0, my = 0;
  for (const p of P) { mx += p[0]; my += p[1]; }
  mx /= P.length; my /= P.length;
  let d = 0;
  for (const p of P) d += Math.hypot(p[0] - mx, p[1] - my);
  const s = Math.SQRT2 / Math.max(d / P.length, 1e-9);
  return [s, 0, -s * mx, 0, s, -s * my, 0, 0, 1];
}
function homographieLS(von, nach) {          // kleinste Quadrate, >= 4 Punkte
  const T1 = normierung(von), T2 = normierung(nach);
  const a = von.map(p => anwenden(T1, p)), b = nach.map(p => anwenden(T2, p));
  const N = Array.from({ length: 8 }, () => new Array(8).fill(0)), r = new Array(8).fill(0);
  const zeile = (z, w) => { for (let i = 0; i < 8; i++) { r[i] += z[i] * w; for (let j = 0; j < 8; j++) N[i][j] += z[i] * z[j]; } };
  for (let k = 0; k < a.length; k++) {
    const [x, y] = a[k], [u, v] = b[k];
    zeile([x, y, 1, 0, 0, 0, -u * x, -u * y], u);
    zeile([0, 0, 0, x, y, 1, -v * x, -v * y], v);
  }
  const h = loese(N, r);
  if (!h) return null;
  const T2i = inv3(T2);
  return T2i ? mul3(mul3(T2i, h.concat([1])), T1) : null;
}
function aehnlichkeit(von, nach, pts) {      // Verschiebung + Drehung + Massstab
  let mvx = 0, mvy = 0, mnx = 0, mny = 0;
  for (let i = 0; i < von.length; i++) { mvx += von[i][0]; mvy += von[i][1]; mnx += nach[i][0]; mny += nach[i][1]; }
  const n = von.length; mvx /= n; mvy /= n; mnx /= n; mny /= n;
  let re = 0, im = 0, nn = 0;
  for (let i = 0; i < n; i++) {
    const ax = von[i][0] - mvx, ay = von[i][1] - mvy, bx = nach[i][0] - mnx, by = nach[i][1] - mny;
    re += ax * bx + ay * by; im += ax * by - ay * bx; nn += ax * ax + ay * ay;
  }
  re /= nn; im /= nn;
  return pts.map(p => { const x = p[0] - mvx, y = p[1] - mvy; return [x * re - y * im + mnx, x * im + y * re + mny]; });
}

/* ---------------- Geometrie ohne Kalibrierung ---------------- */
const H_MM = EINST.markerMM / 2;
const MARKER_ECKEN = () => { const h = EINST.markerMM / 2; return [[-h, h], [h, h], [h, -h], [-h, -h]]; };

function jacobi(H) {                          // Ableitung im Markermittelpunkt
  const s = 1 / H[8], h = H.map(v => v * s);
  return [h[0] - h[2] * h[6], h[1] - h[2] * h[7], h[3] - h[5] * h[6], h[4] - h[5] * h[7]];
}
function loese2(J, r) {
  const det = J[0] * J[3] - J[1] * J[2];
  return [(J[3] * r[0] - J[1] * r[1]) / det, (-J[2] * r[0] + J[0] * r[1]) / det];
}
const norm2 = v => Math.hypot(v[0], v[1]);
const einheit = v => { const l = norm2(v); return [v[0] / l, v[1] / l]; };
const links = u => [-u[1], u[0]];
const mitte = H => [H[2] / H[8], H[5] / H[8]];

/* Lage von Marker b im System von Marker a: Entlang der Verbindungslinie ist die Perspektive
   eine 1D-Projektivitaet -> Abstand = Pixelabstand / sqrt(Massstab_a * Massstab_b). */
function lageZueinander(Ha, Hb) {
  const ca = mitte(Ha), cb = mitte(Hb);
  const D = Math.hypot(cb[0] - ca[0], cb[1] - ca[1]);
  if (D < 1) return null;
  const r = [(cb[0] - ca[0]) / D, (cb[1] - ca[1]) / D];
  const Ja = jacobi(Ha), Jb = jacobi(Hb);
  const ua = einheit(loese2(Ja, r)), ub = einheit(loese2(Jb, r));
  const sa = norm2([Ja[0] * ua[0] + Ja[1] * ua[1], Ja[2] * ua[0] + Ja[3] * ua[1]]);
  const sb = norm2([Jb[0] * ub[0] + Jb[1] * ub[1], Jb[2] * ub[0] + Jb[3] * ub[1]]);
  return { L: D / Math.sqrt(sa * sb), ua, ub };
}

function brennweiteAusHomographie(H, cx, cy) {
  const G = [H[0] - cx * H[6], H[1] - cx * H[7], H[2] - cx * H[8],
             H[3] - cy * H[6], H[4] - cy * H[7], H[5] - cy * H[8], H[6], H[7], H[8]];
  const h1 = [G[0], G[3], G[6]], h2 = [G[1], G[4], G[7]];
  const a1 = h1[0] * h2[0] + h1[1] * h2[1], b1 = h1[2] * h2[2];
  const a2 = h1[0] ** 2 + h1[1] ** 2 - h2[0] ** 2 - h2[1] ** 2, b2 = h1[2] ** 2 - h2[2] ** 2;
  const nenner = a1 * a1 + a2 * a2;
  if (nenner <= 0) return null;
  const x = -(a1 * b1 + a2 * b2) / nenner;
  if (x <= 0) return null;
  const f = 1 / Math.sqrt(x);
  const r1 = [h1[0] / f, h1[1] / f, h1[2]], r2 = [h2[0] / f, h2[1] / f, h2[2]];
  const n = kreuz(r1, r2), nn = Math.hypot(...n);
  if (!nn) return null;
  return { f, neigung: Math.acos(Math.min(1, Math.abs(n[2]) / nn)) * 180 / Math.PI };
}

function brennweiteAusAnlage(marker, cx, cy) {   // alle Marker gemeinsam: lange Basis
  const ids = Object.keys(marker).map(Number).sort((a, b) => a - b);
  if (ids.length < 3) return null;
  const Hr = marker[ids[0]].H, ecken = MARKER_ECKEN();
  const ebene = ecken.slice(), bild = marker[ids[0]].ecken.slice();
  for (const m of ids.slice(1)) {
    const z = lageZueinander(Hr, marker[m].H);
    if (!z) continue;
    const phi = Math.atan2(z.ua[1], z.ua[0]) - Math.atan2(z.ub[1], z.ub[0]);
    const c = Math.cos(phi), s = Math.sin(phi);
    for (let k = 0; k < 4; k++) {
      const [x, y] = ecken[k];
      ebene.push([z.L * z.ua[0] + c * x - s * y, z.L * z.ua[1] + s * x + c * y]);
      bild.push(marker[m].ecken[k]);
    }
  }
  if (ebene.length < 12) return null;
  let mx = 0, my = 0;
  for (const p of ebene) { mx += p[0]; my += p[1]; }
  mx /= ebene.length; my /= ebene.length;
  let sxx = 0, syy = 0, sxy = 0;
  for (const p of ebene) { const dx = p[0] - mx, dy = p[1] - my; sxx += dx * dx; syy += dy * dy; sxy += dx * dy; }
  sxx /= ebene.length; syy /= ebene.length; sxy /= ebene.length;
  const lmin = (sxx + syy) / 2 - Math.sqrt(((sxx - syy) / 2) ** 2 + sxy * sxy);
  if (Math.sqrt(Math.max(lmin, 0)) < 40) return null;   // Marker fast auf einer Linie
  const H = homographieLS(ebene, bild);
  return H ? brennweiteAusHomographie(H, cx, cy) : null;
}

const kreuz = (a, b) => [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]];
const punkt = (a, b) => a[0] * b[0] + a[1] * b[1] + a[2] * b[2];

function poseAusHomographie(H, f, cx, cy) {   // Ebene -> Kamera
  const M = [(H[0] - cx * H[6]) / f, (H[1] - cx * H[7]) / f, (H[2] - cx * H[8]) / f,
             (H[3] - cy * H[6]) / f, (H[4] - cy * H[7]) / f, (H[5] - cy * H[8]) / f, H[6], H[7], H[8]];
  const m1 = [M[0], M[3], M[6]], m2 = [M[1], M[4], M[7]], m3 = [M[2], M[5], M[8]];
  let lam = 2 / (Math.hypot(...m1) + Math.hypot(...m2));
  if (M[8] * lam < 0) lam = -lam;
  const a1 = m1.map(v => v * lam), a2 = m2.map(v => v * lam), a3 = m3.map(v => v * lam);
  let n = kreuz(a1, a2); const nn = Math.hypot(...n); n = n.map(v => v / nn);
  if (punkt(n, a3) > 0) n = n.map(v => -v);
  return { a1, a2, a3, n };
}

/* ---------------- Markererkennung ---------------- */
const WOERTERBUECHER = [
  ["ARUCO_4X4_1000", "4x4"], ["ARUCO_5X5_1000", "5x5"], ["ARUCO_6X6_1000", "6x6"], ["ARUCO_7X7_1000", "7x7"],
  ["ARUCO", "ArUco Original"], ["ARUCO_MIP_36h12", "ArUco MIP 36h12"], ["APRILTAG_36h11", "AprilTag 36h11"],
];

function grauWert(g, w, h, x, y) {           // bilinear
  x = Math.min(Math.max(x, 0), w - 1.001); y = Math.min(Math.max(y, 0), h - 1.001);
  const x0 = x | 0, y0 = y | 0, fx = x - x0, fy = y - y0, i = y0 * w + x0;
  return (g[i] * (1 - fx) + g[i + 1] * fx) * (1 - fy) + (g[i + w] * (1 - fx) + g[i + w + 1] * fx) * fy;
}
function geradeDurch(pts) {
  let mx = 0, my = 0;
  for (const p of pts) { mx += p[0]; my += p[1]; }
  mx /= pts.length; my /= pts.length;
  let sxx = 0, syy = 0, sxy = 0;
  for (const p of pts) { const dx = p[0] - mx, dy = p[1] - my; sxx += dx * dx; syy += dy * dy; sxy += dx * dy; }
  const w = 0.5 * Math.atan2(2 * sxy, sxx - syy);
  return { p: [mx, my], d: [Math.cos(w), Math.sin(w)] };
}
function schnitt(l1, l2) {
  const det = l1.d[0] * -l2.d[1] - l1.d[1] * -l2.d[0];
  if (Math.abs(det) < 1e-9) return null;
  const rx = l2.p[0] - l1.p[0], ry = l2.p[1] - l1.p[1];
  const t = (rx * -l2.d[1] - ry * -l2.d[0]) / det;
  return [l1.p[0] + t * l1.d[0], l1.p[1] + t * l1.d[1]];
}
/* Ecken auf Subpixel verfeinern: Kanten des schwarzen Rands abtasten, Geraden fitten, schneiden. */
function verfeinere(g, w, h, ecken) {
  const cx = ecken.reduce((s, p) => s + p[0], 0) / 4, cy = ecken.reduce((s, p) => s + p[1], 0) / 4;
  const geraden = [];
  for (let k = 0; k < 4; k++) {
    const a = ecken[k], b = ecken[(k + 1) % 4];
    const dx = b[0] - a[0], dy = b[1] - a[1], len = Math.hypot(dx, dy);
    if (len < 8) return ecken;
    let nx = -dy / len, ny = dx / len;                       // Normale nach innen
    if (nx * (cx - a[0]) + ny * (cy - a[1]) < 0) { nx = -nx; ny = -ny; }
    const N = Math.max(5, Math.min(14, Math.floor(len / 3))), R = 3, S = 0.5, pts = [];
    for (let i = 0; i < N; i++) {
      const t = 0.12 + 0.76 * i / (N - 1), px = a[0] + dx * t, py = a[1] + dy * t;
      const prof = [];
      for (let j = -R / S; j <= R / S; j++) prof.push(grauWert(g, w, h, px + nx * j * S, py + ny * j * S));
      let best = 0, bi = -1;
      for (let j = 2; j < prof.length - 2; j++) {
        const gr = prof[j - 1] - prof[j + 1];                  // hell (aussen) -> dunkel (innen)
        if (gr > best) { best = gr; bi = j; }
      }
      if (bi < 0 || best < 12) continue;
      const g0 = prof[bi - 2] - prof[bi], g2 = prof[bi] - prof[bi + 2];
      const den = g0 - 2 * best + g2, off = den !== 0 ? 0.5 * (g0 - g2) / den : 0;
      const d = (bi + Math.max(-1, Math.min(1, off)) - R / S) * S;
      pts.push([px + nx * d, py + ny * d]);
    }
    if (pts.length < 4) return ecken;
    geraden.push(geradeDurch(pts));
  }
  const neu = [];
  for (let k = 0; k < 4; k++) {
    const p = schnitt(geraden[(k + 3) % 4], geraden[k]);
    if (!p || Math.hypot(p[0] - ecken[k][0], p[1] - ecken[k][1]) > 4) return ecken;
    neu.push(p);
  }
  return neu;
}

function schrumpfe(q, d) {                  // Ecken um d Pixel Richtung Mitte ziehen
  const cx = (q[0][0] + q[1][0] + q[2][0] + q[3][0]) / 4, cy = (q[0][1] + q[1][1] + q[2][1] + q[3][1]) / 4;
  return q.map(p => { const vx = cx - p[0], vy = cy - p[1], l = Math.hypot(vx, vy) || 1; return { x: p[0] + vx / l * d, y: p[1] + vy / l * d }; });
}

class Erkennung {
  constructor(ids) {
    this.ids = new Set(ids);
    this.det = new AR.Detector({ dictionaryName: "ARUCO" });
    this.woerter = [];
    for (const [name, anzeige] of WOERTERBUECHER) {
      const def = AR.DICTIONARIES[name];
      if (!def) continue;
      const kurz = name + "_ERSTE50";
      AR.DICTIONARIES[kurz] = { nBits: def.nBits, codeList: def.codeList.slice(0, 50) };
      const d = new AR.Dictionary(kurz);                     // tau = Mindestabstand der 50 Codes
      d.tau = Math.floor((d.tau - 1) / 2) + 1;               // nur sicher korrigierbare Bitfehler
      this.woerter.push({ name, anzeige, d });
    }
    this.gewaehlt = null;
    this.stimmen = {};
  }
  waehle(name) { this.gewaehlt = name ? this.woerter.find(w => w.name === name) || null : null; this.stimmen = {}; }
  get name() { const w = this.gewaehlt || this.letztes; return w ? w.anzeige : null; }

  /* Kandidat entzerren und binarisieren (einmal je Kandidat, fuer alle Woerterbuecher) */
  _raster(kand) {
    const det = this.det;
    CV.warp(det.grey, det.homography, kand, 49);
    CV.threshold(det.homography, det.homography, CV.otsu(det.homography));
    return { width: 49, height: 49, data: det.homography.data.slice() };
  }
  _dekodiere(wort, kandidaten) {
    this.det.dictionary = wort.d;
    const erg = {};
    for (const k of kandidaten) {
      // 1. Versuch: Ecken wie von js-aruco2 gefunden; 2. Versuch: Subpixel-Ecken, leicht nach innen
      const m = this.det.getMarker(k.roh.bild, k.roh.kand) || (k.fein && this.det.getMarker(k.fein.bild, k.fein.kand));
      if (m && this.ids.has(m.id) && !erg[m.id]) erg[m.id] = m.corners.map(c => [c.x, c.y]);
    }
    return erg;
  }
  /* imageData in Verarbeitungsaufloesung; skala: Faktor zur Anzeigeaufloesung */
  erkenne(imageData, skala) {
    const det = this.det;
    CV.grayscale(imageData, det.grey);
    CV.adaptiveThreshold(det.grey, det.thres, 2, 7);
    det.contours = CV.findContours(det.thres, det.binary);
    const g = det.grey.data, w = det.grey.width, h = det.grey.height;
    const roh = det.notTooNear(det.clockwiseCorners(
      det.findCandidates(det.contours, imageData.width * 0.01, 0.05, 10)), 10);
    // js-aruco2 tastet auf seine ganzzahligen Ecken abgestimmt ab. Bei kleinen Markern liegen die
    // 1-3 px daneben und Randzellen werden falsch gelesen -> zweiter Versuch mit Subpixel-Ecken.
    const kandidaten = roh.map(c => {
      const eingang = c.map(p => [p.x, p.y]), f = verfeinere(g, w, h, eingang);
      const k = { roh: { kand: c, bild: this._raster(c) }, fein: null };
      if (f !== eingang) {
        const kl = schrumpfe(f, EINST.eckenEinzug);
        k.fein = { kand: kl, bild: this._raster(kl) };
      }
      return k;
    });
    let erg = {};
    if (this.gewaehlt) erg = this._dekodiere(this.gewaehlt, kandidaten);
    else {
      let bester = null;
      for (const wort of this.woerter) {
        const e = this._dekodiere(wort, kandidaten);
        if (Object.keys(e).length > Object.keys(erg).length) { erg = e; bester = wort; }
      }
      if (bester) {
        this.letztes = bester;
        this.stimmen[bester.name] = (this.stimmen[bester.name] || 0) + Object.keys(erg).length;
        if (this.stimmen[bester.name] >= 6) this.gewaehlt = bester;
      }
    }
    for (const id in erg) erg[id] = verfeinere(g, w, h, erg[id]);   // Ausgabe: Subpixel-Ecken
    const aus = {};
    for (const id in erg) aus[id] = erg[id].map(p => [p[0] * skala, p[1] * skala]);
    return aus;
  }
}

/* ---------------- Kamera (Lochkamera, Brennweite geschaetzt) ---------------- */
class Kamera {
  constructor(w, h) { this.setze(w, h); }
  setze(w, h) {
    if (w === this.w && h === this.h) return;
    this.w = w; this.h = h; this.cx = w / 2; this.cy = h / 2;
    this.schaetzungen = []; this.fAuto = null; this.fManuell = null;
  }
  get f() { return this.fManuell || this.fAuto || 0.8 * Math.max(this.w, this.h); }
  get quelle() { return this.fManuell ? "manuell" : this.fAuto ? "geschätzt" : "Startwert"; }
  lerne(marker) {
    if (this.fManuell) return;
    const r = brennweiteAusAnlage(marker, this.cx, this.cy);
    const W = Math.max(this.w, this.h);
    if (r && r.neigung >= 15 && r.neigung <= 80 && r.f > 0.25 * W && r.f < 5 * W) {
      this.schaetzungen.push(r.f);
      if (this.schaetzungen.length > 600) this.schaetzungen.shift();
      if (this.schaetzungen.length >= 1) {
        const s = this.schaetzungen.slice().sort((a, b) => a - b);
        this.fAuto = s[s.length >> 1];
      }
    }
  }
  projiziere(X) { const Z = Math.max(X[2], 1e-3); return [this.f * X[0] / Z + this.cx, this.f * X[1] / Z + this.cy]; }
}

/* ---------------- Personensimulation (Vorbild-Meter) ---------------- */
function Zufall(seed) {                       // kleiner, reproduzierbarer Zufallsgenerator
  let s = (seed >>> 0) || 1;
  const r = () => { s ^= s << 13; s >>>= 0; s ^= s >>> 17; s ^= s << 5; s >>>= 0; return s / 4294967296; };
  r.gleich = (a, b) => a + (b - a) * r();
  r.normal = () => Math.sqrt(-2 * Math.log(r() + 1e-12)) * Math.cos(2 * Math.PI * r());
  r.poisson = l => { let k = 0, p = 1; const L = Math.exp(-l); do { k++; p *= r(); } while (p > L); return k - 1; };
  return r;
}

class Person {
  constructor(pos, ziel, zustand, stimmung, rnd) {
    this.pos = pos.slice(); this.vel = [0, 0]; this.ziel = ziel.slice();
    this.zustand = zustand; this.stimmung = Math.min(1, Math.max(0, stimmung));
    this.warte = 0; this.tempo = rnd.gleich(1.0, 1.5); this.groesse = rnd.gleich(1.62, 1.92);
    this.spur = []; this.spurT = 0; this.verz = 0; this.schritt = rnd.gleich(0, 2 * Math.PI);
  }
}

class Simulation {
  constructor(gleis, rnd) {
    this.rnd = rnd;
    this.seiten = gleis === "links" ? [1] : gleis === "rechts" ? [-1] : [1, -1];
    this.L = 25; this.W = 4.3; this.personen = []; this.t = 0;
    this.phase = "weg"; this.timer = rnd.gleich(10, 30); this.fahrt = 0; this.seite = this.seiten[0];
    this.verspaetung = false; this.warVerspaetet = false; this.andrang = 1;
    this.wellenPhase = rnd.gleich(0, 2 * Math.PI); this.zu = []; this.ab = [];
  }
  setzeMasse(L, W) { this.L = Math.max(L, 3); this.W = Math.max(W, 1.5); }
  tueren() {
    const n = Math.max(2, Math.round(this.L / 7)), r = [];
    for (let i = 0; i < n; i++) r.push(this.L * (0.1 + 0.8 * i / (n - 1)));
    return r;
  }
  _zugang() {
    const r = this.rnd(), W = this.W;
    if (r < 0.35) return [0.3, this.rnd.gleich(-0.25, 0.25) * W];
    if (r < 0.7) return [this.L - 0.3, this.rnd.gleich(-0.25, 0.25) * W];
    return [0.5 * this.L + this.rnd.gleich(-0.5, 0.5), this.rnd.gleich(-0.1, 0.1) * W];
  }
  _ausgang(pos) {
    const kand = [0.3, this.L - 0.3, 0.5 * this.L], g = kand.map(s => Math.exp(-Math.abs(s - pos[0]) / 6));
    let r = this.rnd() * g.reduce((a, b) => a + b), i = 0;
    while (i < 2 && r > g[i]) { r -= g[i]; i++; }
    return [kand[i], this.rnd.gleich(-0.2, 0.2) * this.W];
  }
  _warteplatz() {
    const s = this.rnd.gleich(0.06, 0.94) * this.L;
    const [lo, hi] = this.seiten.length === 2 ? [-0.38, 0.38] : this.seiten[0] === 1 ? [0, 0.38] : [-0.38, 0];
    return [s, this.rnd.gleich(lo, hi) * this.W];
  }
  _tuerplatz(s) {
    const tu = this.tueren(); let best = tu[0];
    for (const x of tu) if (Math.abs(x - s) < Math.abs(best - s)) best = x;
    return [best + this.rnd.gleich(-0.3, 0.3), this.seite * (this.W / 2 - 0.15)];
  }
  sichtbare() { return this.personen.filter(p => p.zustand !== "im_zug"); }
  anzahl() { return this.sichtbare().length; }
  stimmung() { const s = this.sichtbare(); return s.length ? s.reduce((a, p) => a + p.stimmung, 0) / s.length : 1; }
  welle() { return 0.3 + 0.7 * (0.5 + 0.5 * Math.sin(2 * Math.PI * this.t / 180 + this.wellenPhase)); }
  statustext() {
    if (this.phase === "weg") return this.verspaetung ? "Zug verspätet" : `Nächster Zug in ${Math.max(0, this.timer / EINST.zeitraffer).toFixed(0)} s`;
    return { einfahrt: "Zug fährt ein", haelt: "Zug hält – Ein- und Aussteigen", ausfahrt: "Zug fährt ab" }[this.phase];
  }
  einfahrt() {
    if (this.phase !== "weg") return;
    this.phase = "einfahrt"; this.fahrt = 0;
    this.seite = this.seiten[Math.floor(this.rnd() * this.seiten.length)];
  }
  _einsteigen(p, verz) {
    p.zustand = "steigt_ein"; p.verz = verz == null ? this.rnd.gleich(0.3, 6) : verz;
    p.ziel = this._tuerplatz(p.pos[0]); p.stimmung = Math.min(1, p.stimmung + 0.15);
  }
  _tuerenAuf() {
    const rnd = this.rnd, tu = this.tueren();
    const n = rnd.poisson(2 + 6 * this.andrang * this.welle() * this.L / 25);
    for (let i = 0; i < n && this.personen.length < EINST.maxPersonen; i++) {
      const s = tu[Math.floor(rnd() * tu.length)] + rnd.gleich(-0.4, 0.4);
      const p = new Person([s, this.seite * (this.W / 2 - 0.2)], [0, 0], "im_zug",
        rnd.gleich(0.6, 0.92) - (this.warVerspaetet ? 0.35 : 0), rnd);
      p.verz = rnd.gleich(0, 7); p.ziel = this._ausgang(p.pos);
      this.personen.push(p);
    }
    const anteil = this.seiten.length === 1 ? 1 : 0.6;
    for (const p of this.personen) if ((p.zustand === "wartet" || p.zustand === "kommt") && rnd() < anteil) this._einsteigen(p);
    this.warVerspaetet = false;
  }
  _tuerenZu() {
    for (const p of this.personen) {
      if (p.zustand === "steigt_ein") { p.zustand = "wartet"; p.ziel = p.pos.slice(); p.stimmung = Math.max(0, p.stimmung - 0.35); }
      else if (p.zustand === "im_zug") p.verz = 0;
    }
  }
  _zug(dt) {
    if (this.phase === "weg") {
      if (!this.verspaetung) { this.timer -= dt; if (this.timer <= 0) this.einfahrt(); }
    } else if (this.phase === "einfahrt") {
      this.fahrt += dt / 6;
      if (this.fahrt >= 1) { this.phase = "haelt"; this.timer = EINST.haltezeit; this._tuerenAuf(); }
    } else if (this.phase === "haelt") {
      this.timer -= dt;
      if (this.timer <= 0) { this.phase = "ausfahrt"; this.fahrt = 0; this._tuerenZu(); }
    } else {
      this.fahrt += dt / 6;
      if (this.fahrt >= 1) { this.phase = "weg"; this.timer = this.rnd.gleich(...EINST.zugtakt); }
    }
  }
  schritt(dtEcht) {
    const dt = Math.min(dtEcht, 0.1) * EINST.zeitraffer;
    if (dt <= 0) return;
    this.t += dt;
    if (this.verspaetung) this.warVerspaetet = true;
    const rate = EINST.grundandrang * this.andrang * this.welle() * this.L / 25;
    const n = this.rnd.poisson(rate * dt);
    for (let i = 0; i < n && this.personen.length < EINST.maxPersonen; i++) {
      this.personen.push(new Person(this._zugang(), this._warteplatz(), "kommt",
        this.rnd.gleich(0.62, 0.95) - (this.verspaetung ? 0.3 : 0), this.rnd));
      this.zu.push(this.t);
    }
    this._zug(dt);
    this._bewegen(dt);
    while (this.zu.length && this.zu[0] < this.t - 60) this.zu.shift();
    while (this.ab.length && this.ab[0] < this.t - 60) this.ab.shift();
  }
  _bewegen(dt) {
    const rnd = this.rnd, L = this.L, W = this.W;
    for (const p of this.personen) if (p.zustand === "im_zug") {
      p.verz -= dt;
      if (p.verz <= 0) { p.zustand = "geht"; this.zu.push(this.t); }
    }
    const aktiv = this.sichtbare(), n = aktiv.length;
    if (!n) return;
    const nachbarn = new Array(n).fill(0), stoss = aktiv.map(() => [0, 0]), R = 0.6;
    for (let i = 0; i < n; i++) for (let j = i + 1; j < n; j++) {
      const dx = aktiv[i].pos[0] - aktiv[j].pos[0], dy = aktiv[i].pos[1] - aktiv[j].pos[1];
      const d = Math.max(Math.hypot(dx, dy), 1e-6);
      if (d < 1.3) { nachbarn[i]++; nachbarn[j]++; }
      if (d < R) {
        const w = (R - d) / R * 1.4 / d;
        stoss[i][0] += dx * w; stoss[i][1] += dy * w; stoss[j][0] -= dx * w; stoss[j][1] -= dy * w;
      }
    }
    const einzel = this.seiten.length === 1, weg = new Set();
    aktiv.forEach((p, i) => {
      const dichte = Math.max(0, nachbarn[i] - 2);
      const zx = p.ziel[0] - p.pos[0], zy = p.ziel[1] - p.pos[1], dist = Math.hypot(zx, zy);
      const laufen = p.zustand === "kommt" || p.zustand === "geht" || (p.zustand === "steigt_ein" && p.verz <= 0);
      let vx, vy;
      if (laufen) {
        const k = p.tempo * Math.min(1, dist / 0.8) / (1 + 0.12 * dichte) / Math.max(dist, 1e-6);
        vx = zx * k + stoss[i][0]; vy = zy * k + stoss[i][1];
      } else { vx = zx * 0.6 + 0.7 * stoss[i][0]; vy = zy * 0.6 + 0.7 * stoss[i][1]; }
      const a = Math.min(1, 4 * dt);
      p.vel[0] += (vx - p.vel[0]) * a; p.vel[1] += (vy - p.vel[1]) * a;
      p.pos[0] += p.vel[0] * dt; p.pos[1] += p.vel[1] * dt;
      const rand = p.zustand === "steigt_ein" ? 0.12 : 0.22;
      p.pos[0] = Math.min(Math.max(p.pos[0], 0.1), L - 0.1);
      p.pos[1] = Math.min(Math.max(p.pos[1], -W / 2 + rand), W / 2 - rand);
      const tempo = Math.hypot(p.vel[0], p.vel[1]);
      p.schritt += tempo * dt * 5;
      p.spurT += dt;
      if (tempo > 0.3) { if (p.spurT > 0.4) { p.spur.push(p.pos.slice()); if (p.spur.length > 12) p.spur.shift(); p.spurT = 0; } }
      else if (p.spur.length && p.spurT > 0.3) { p.spur.shift(); p.spurT = 0; }
      if (p.zustand === "kommt") {
        if (dist < 0.4) {
          if (this.phase === "haelt" && this.timer > 6 && (einzel || rnd() < 0.6)) this._einsteigen(p, 0);
          else p.zustand = "wartet";
        }
      } else if (p.zustand === "wartet") {
        p.warte += dt;
        if (rnd() < 0.04 * dt) {
          p.ziel = [Math.min(Math.max(p.ziel[0] + 0.4 * rnd.normal(), 0.5), L - 0.5),
                    Math.min(Math.max(p.ziel[1] + 0.4 * rnd.normal(), -0.38 * W), 0.38 * W)];
        }
      } else if (p.zustand === "steigt_ein") {
        if (p.verz > 0) p.verz -= dt;
        else if (dist < 0.35) { weg.add(p); this.ab.push(this.t); }
      } else if (p.zustand === "geht" && dist < 0.5) { weg.add(p); this.ab.push(this.t); }
      if (p.zustand === "kommt" || p.zustand === "wartet") {
        p.stimmung -= (0.002 + 0.005 * dichte + (p.warte > 60 ? 0.006 : 0) + (this.verspaetung ? 0.02 : 0)) * dt;
      } else if (p.zustand === "steigt_ein") p.stimmung += 0.02 * dt;
      else p.stimmung += (0.008 - 0.004 * dichte) * dt;
      p.stimmung = Math.min(1, Math.max(0, p.stimmung));
    });
    if (weg.size) this.personen = this.personen.filter(p => !weg.has(p));
  }
}

/* ---------------- Bahnsteig: Tracking ---------------- */
class Bahnsteig {
  constructor(cfg, rnd) {
    this.cfg = cfg; this.name = cfg.name; [this.idA, this.idB] = cfg.marker;
    this.sim = new Simulation(cfg.gleis, rnd);
    this.Lp = null; this.quad = null; this.referenz = null; this.gesehen = new Set();
    this.zuletzt = -1e9; this.H = null; this.pose = null;
  }
  zuruecksetzen() { this.Lp = null; this.quad = null; this.referenz = null; this.H = null; this.zuletzt = -1e9; }
  aktualisiere(marker, jetzt) {
    const A = marker[this.idA], B = marker[this.idB];
    this.gesehen = new Set([this.idA, this.idB].filter(i => marker[i]));
    const W = this.cfg.breite, e = this.cfg.ueberstand, dv = this.cfg.versatz;
    let quad = null;
    if (A && B) {
      const z = lageZueinander(A.H, B.H);
      if (!z || z.L < 1.2 * EINST.markerMM || z.L > 5000) return;
      const uA = z.ua, uB = z.ub, nA = links(uA), nB = links(uB);
      const pA = s => [-e * uA[0] + (dv + s) * nA[0], -e * uA[1] + (dv + s) * nA[1]];
      const pB = s => [e * uB[0] + (dv + s) * nB[0], e * uB[1] + (dv + s) * nB[1]];
      quad = [anwenden(A.H, pA(-W / 2)), anwenden(B.H, pB(-W / 2)), anwenden(B.H, pB(W / 2)), anwenden(A.H, pA(W / 2))];
      const Lp = z.L + 2 * e;
      this.Lp = this.Lp == null ? Lp : 0.85 * this.Lp + 0.15 * Lp;
      const alle = {};
      for (const id in marker) alle[id] = marker[id].ecken.map(p => p.slice());
      this.referenz = { quad: quad.map(p => p.slice()), ecken: alle };
    } else if (this.referenz) {
      // Bahnsteigmarker verdeckt: Ebene ueber alle anderen Marker weiterverfolgen
      const gemeinsam = Object.keys(marker).filter(id => this.referenz.ecken[id]);
      if (gemeinsam.length >= 2) {
        const von = [], nach = [];
        for (const id of gemeinsam) { von.push(...this.referenz.ecken[id]); nach.push(...marker[id].ecken); }
        const M = homographieLS(von, nach);
        if (M) quad = this.referenz.quad.map(p => anwenden(M, p));
      } else if (gemeinsam.length === 1) {
        const id = gemeinsam[0];
        quad = aehnlichkeit(this.referenz.ecken[id], marker[id].ecken, this.referenz.quad);
      }
    }
    if (!quad || this.Lp == null || !quad.every(p => isFinite(p[0]) && isFinite(p[1])) || !konvex(quad)) return;
    if (!this.quad) this.quad = quad;
    else {
      let diff = 0;
      for (let k = 0; k < 4; k++) diff = Math.max(diff, Math.hypot(quad[k][0] - this.quad[k][0], quad[k][1] - this.quad[k][1]));
      const a = Math.min(1, 0.25 + diff / 12);
      this.quad = this.quad.map((p, k) => [p[0] + a * (quad[k][0] - p[0]), p[1] + a * (quad[k][1] - p[1])]);
    }
    this.H = homographie([[0, -W / 2], [this.Lp, -W / 2], [this.Lp, W / 2], [0, W / 2]], this.quad);
    this.zuletzt = jetzt;
    const k = EINST.massstab / 1000;
    this.sim.setzeMasse(this.Lp * k, W * k);
  }
  sichtbar(jetzt) { return this.H && jetzt - this.zuletzt < EINST.haltenS; }
  status(jetzt) {
    if (this.Lp == null) return `Marker ${this.idA} und ${this.idB} zusammen ins Bild`;
    if (!this.sichtbar(jetzt)) return "nicht im Bild";
    const fehlt = [this.idA, this.idB].filter(i => !this.gesehen.has(i));
    if (!fehlt.length) return "ok";
    return fehlt.length === 1 ? `Marker ${fehlt[0]} verdeckt` : "Marker verdeckt – halte Position";
  }
  berechnePose(kam) { this.pose = poseAusHomographie(this.H, kam.f, kam.cx, kam.cy); }
  /* Vorbild-Meter (s, t, z) -> Kamerakoordinaten (mm) */
  kamerapunkt(s, t, z) {
    const k = 1000 / EINST.massstab, P = this.pose;
    s *= k; t *= k; z *= k;
    return [s * P.a1[0] + t * P.a2[0] + P.a3[0] + z * P.n[0],
            s * P.a1[1] + t * P.a2[1] + P.a3[1] + z * P.n[1],
            s * P.a1[2] + t * P.a2[2] + P.a3[2] + z * P.n[2]];
  }
}
function konvex(q) {
  let vz = 0;
  for (let k = 0; k < 4; k++) {
    const a = q[k], b = q[(k + 1) % 4], c = q[(k + 2) % 4];
    const cr = (b[0] - a[0]) * (c[1] - b[1]) - (b[1] - a[1]) * (c[0] - b[0]);
    if (Math.abs(cr) < 1e-9) return false;
    if (!vz) vz = Math.sign(cr); else if (Math.sign(cr) !== vz) return false;
  }
  return true;
}

/* ---------------- Gesamtablauf ohne Zeichnen ---------------- */
class Szene {
  constructor(seed) {
    const ids = new Set([0, 1, 2, 3, 4, 5, 6, 7]);
    EINST.bahnsteige.forEach(b => b.marker.forEach(i => ids.add(i)));
    this.erk = new Erkennung(ids);
    if (EINST.woerterbuch) this.erk.waehle(EINST.woerterbuch);
    this.kam = new Kamera(1280, 720);
    const rnd = Zufall(seed || 12345);
    this.steige = EINST.bahnsteige.map(c => new Bahnsteig(c, rnd));
    this.zeit = 0; this.pause = false; this.andrang = 1; this.verspaetung = false;
    this.ecken = {};
  }
  /* bild: ImageData in Verarbeitungsaufloesung; skala: Verarbeitungs- -> Anzeigepixel */
  verarbeite(bild, skala, anzeigeW, anzeigeH) {
    this.kam.setze(anzeigeW, anzeigeH);
    const ecken = this.erk.erkenne(bild, skala);
    this.ecken = ecken;
    const marker = {}, E = MARKER_ECKEN();
    for (const id in ecken) {
      const H = homographie(E, ecken[id]);
      if (H) marker[id] = { H, ecken: ecken[id] };
    }
    this.kam.lerne(marker);
    for (const b of this.steige) b.aktualisiere(marker, this.zeit);
    return marker;
  }
  simuliere(dt) {
    this.zeit += dt;
    for (const b of this.steige) {
      b.sim.andrang = this.andrang; b.sim.verspaetung = this.verspaetung;
      if (!this.pause) b.sim.schritt(dt);
    }
  }
  sichtbare() {
    const s = this.steige.filter(b => b.sichtbar(this.zeit));
    for (const b of s) b.berechnePose(this.kam);
    return s;
  }
  setzeVerspaetung(an) {
    this.verspaetung = an;
    if (!an) for (const b of this.steige) b.sim.timer = Math.min(b.sim.timer, 4);
  }
}

if (typeof module !== "undefined") module.exports = { EINST, Szene, homographie, homographieLS, anwenden, lageZueinander, brennweiteAusAnlage, verfeinere };
