// Tests der Web-Version (Node >= 18):  npm install  &&  python tests/web/erzeuge_testdaten.py  &&  npm test
"use strict";
const test = require("node:test");
const assert = require("node:assert");
const fs = require("fs");
const path = require("path");
const vm = require("vm");

const WURZEL = path.join(__dirname, "..", "..");
const DATEN = path.join(__dirname, "daten");
const LIB = path.join(WURZEL, "node_modules", "js-aruco2", "src");
const LIB_DATEIEN = ["cv.js", "aruco.js", "dictionaries/aruco_4x4_1000.js", "dictionaries/aruco_5x5_1000.js",
  "dictionaries/aruco_6x6_1000.js", "dictionaries/aruco_7x7_1000.js", "dictionaries/apriltag_36h11.js"];

if (!fs.existsSync(path.join(DATEN, "meta.json"))) throw new Error("Testdaten fehlen: erst  python tests/web/erzeuge_testdaten.py  ausführen");
if (!fs.existsSync(LIB)) throw new Error("js-aruco2 fehlt: erst  npm install  ausführen");
const META = JSON.parse(fs.readFileSync(path.join(DATEN, "meta.json"), "utf8"));
const rgba = datei => new Uint8ClampedArray(fs.readFileSync(path.join(DATEN, datei)));

/** Neuer Kontext mit js-aruco2 (+ optional kern.js), so wie die Skripte im Browser geladen werden. */
function kontext(extra = {}, mitKern = true) {
  const ctx = Object.assign({ console, Math, Array, Object, Set, Number, String, isFinite, Date, JSON, parseInt,
    Uint8ClampedArray, Int32Array, Float32Array, Uint8Array, Float64Array }, extra);
  ctx.window = ctx;
  vm.createContext(ctx);
  const lade = datei => vm.runInContext(fs.readFileSync(datei, "utf8").replace(/require\([^)]*\)/g, "undefined"), ctx, { filename: datei });
  LIB_DATEIEN.forEach(f => lade(path.join(LIB, f)));
  if (mitKern) {
    lade(path.join(WURZEL, "web", "kern.js"));
    vm.runInContext("globalThis.Szene = Szene; globalThis.EINST = EINST;", ctx);
  }
  return ctx;
}
const median = a => { const s = a.slice().sort((x, y) => x - y); return s[s.length >> 1]; };

test("js-aruco2 liefert für alle Wörterbücher dieselben IDs wie OpenCV", () => {
  const ctx = kontext({}, false);
  for (const [cvName, jsName] of Object.entries(META.woerterbuecher)) {
    const det = new ctx.AR.Detector({ dictionaryName: jsName });
    const ids = det.detect({ width: 1000, height: 300, data: rgba(`wb_${cvName}.rgba`) }).map(m => m.id).filter(i => i < 8);
    assert.deepStrictEqual([...new Set(ids)].sort(), [0, 1, 2, 3, 4, 5, 6, 7], cvName);
  }
});

test("Kern verfolgt beide Bahnsteige der synthetischen Szene", () => {
  const ctx = kontext();
  ctx.EINST.bahnsteige.forEach((b, i) => { b.breite = META.breiten[i]; });
  const sz = new ctx.Szene(7);
  const [pw, ph] = META.fahrt_groesse, [aw, ah] = META.anzeige_groesse;
  const fehler = [[], []];
  META.fahrt.forEach((m, i) => {
    sz.verarbeite({ width: pw, height: ph, data: rgba(`fahrt_${String(i).padStart(2, "0")}.rgba`) }, aw / pw, aw, ah);
    sz.simuliere(0.2);
    sz.steige.forEach((b, j) => {
      if (!b.quad || !b.sichtbar(sz.zeit)) return;
      const q = m.quads[j];
      const e1 = Math.max(...b.quad.map((p, k) => Math.hypot(p[0] - q[k][0], p[1] - q[k][1])));
      const e2 = Math.max(...b.quad.map((p, k) => Math.hypot(p[0] - q[3 - k][0], p[1] - q[3 - k][1])));
      fehler[j].push(Math.min(e1, e2));
    });
  });
  assert.strictEqual(sz.erk.name, "ArUco Original");
  sz.steige.forEach((b, j) => {
    assert.strictEqual(fehler[j].length, META.fahrt.length, `${b.name} muss durchgehend verfolgt werden`);
    assert.ok(median(fehler[j]) < 3, `${b.name}: Median-Eckfehler ${median(fehler[j]).toFixed(2)} px`);
    assert.ok(Math.max(...fehler[j]) < 6, `${b.name}: max. Eckfehler ${Math.max(...fehler[j]).toFixed(2)} px`);
    assert.ok(Math.abs(b.Lp - META.laenge_wahr) / META.laenge_wahr < 0.03, `${b.name}: Länge ${b.Lp.toFixed(1)} mm`);
  });
  assert.ok(Math.abs(sz.kam.f - META.f_wahr) / META.f_wahr < 0.1, `Brennweite ${sz.kam.f.toFixed(0)} px`);
});

test("Seite startet, erkennt das Beispielbild und animiert (Browser nachgebildet)", async () => {
  const [bw, bh] = META.beispiel_groesse, bild = rgba("beispiel.rgba");
  const ctx2d = new Proxy({}, {
    get: (o, k) => k in o ? o[k] : k === "measureText" ? () => ({ width: 80 })
      : k === "getImageData" ? (x, y, w, h) => ({ width: w, height: h, data: bild }) : () => {},
    set: (o, k, v) => ((o[k] = v), true),
  });
  const els = {};
  const element = () => ({ style: {}, classList: { toggle() {} }, setAttribute() {}, appendChild() {}, addEventListener() {},
    getContext: () => ctx2d, clientWidth: 400, dataset: {}, textContent: "", innerHTML: "", hidden: true, value: "" });
  els.breite1 = Object.assign(element(), { value: "70" });
  els.breite2 = Object.assign(element(), { value: "37" });
  const g = kontext({
    setTimeout, setInterval: () => 0, performance: { now: () => Date.now() }, navigator: {},
    URL: { createObjectURL: () => "blob:x" },
    requestAnimationFrame: f => { g.__raf = f; },
    Image: function () { const i = this; i.naturalWidth = bw; i.naturalHeight = bh; Object.defineProperty(i, "src", { set() { setTimeout(() => i.onload(), 0); } }); },
    document: { readyState: "loading", getElementById: id => els[id] || (els[id] = element()), createElement: () => element(), querySelectorAll: () => [] },
    addEventListener: (n, f) => { g.__load = f; },
  });
  g.top = g; g.self = g;
  const html = fs.readFileSync(path.join(WURZEL, "web", "index.html"), "utf8");
  const skripte = [...html.matchAll(/<script>([\s\S]*?)<\/script>/g)].map(m => m[1]);
  assert.strictEqual(skripte.length, 1, "index.html soll genau ein Inline-Skript haben");
  vm.runInContext(skripte[0], g, { filename: "index.html" });
  await new Promise(r => setTimeout(r, 10));
  g.__load();
  let t = 0;
  for (let i = 0; i < 120; i++) { t += 33; g.__raf(t); }
  vm.runInContext("tafel()", g);
  assert.match(els.hinweis.textContent, /Marker erkannt/);
  const status = vm.runInContext("szene.steige.map(b => b.status(szene.zeit))", g);
  assert.deepStrictEqual([...status], ["ok", "ok"]);
  assert.ok(vm.runInContext("szene.steige.reduce((s, b) => s + b.sim.anzahl(), 0)", g) > 0, "es sollen Personen unterwegs sein");
});
