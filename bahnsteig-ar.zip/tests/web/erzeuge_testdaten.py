"""Erzeugt Testdaten fuer tests/web/web.test.js (einmal vor `npm test` ausfuehren):
  - Kamerabilder der synthetischen Szene (960 x 540, RGBA) mit Soll-Bahnsteigecken
  - je Woerterbuch ein Bild mit den Markern 0-7 (Abgleich js-aruco2 <-> OpenCV)
  - das Beispielbild der Web-Seite als RGBA
Aufruf: python tests/web/erzeuge_testdaten.py"""
import json
import os
import sys

import cv2
import numpy as np

HIER = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HIER, ".."))
import szene  # noqa: E402

DATEN = os.path.join(HIER, "daten")
# OpenCV-Name -> Name in js-aruco2
WOERTERBUECHER = {"DICT_4X4_50": "ARUCO_4X4_1000", "DICT_5X5_50": "ARUCO_5X5_1000",
                  "DICT_6X6_50": "ARUCO_6X6_1000", "DICT_7X7_50": "ARUCO_7X7_1000",
                  "DICT_ARUCO_ORIGINAL": "ARUCO", "DICT_ARUCO_MIP_36h12": "ARUCO_MIP_36h12",
                  "DICT_APRILTAG_36h11": "APRILTAG_36h11"}


def rgba(bild, datei):
    cv2.cvtColor(bild, cv2.COLOR_BGR2RGBA if bild.ndim == 3 else cv2.COLOR_GRAY2RGBA).tofile(os.path.join(DATEN, datei))


if __name__ == "__main__":
    os.makedirs(DATEN, exist_ok=True)
    # 1) Kamerafahrt (jedes 4. Bild), verkleinert auf 960 x 540 wie auf dem Handy
    tex, meta = szene.textur(), []
    for i, k in enumerate(range(0, 160, 4)):
        bild, Hw = szene.render(tex, k, szene.verdeckte(k))
        rgba(cv2.resize(bild, (960, 540), interpolation=cv2.INTER_AREA), f"fahrt_{i:02d}.rgba")
        meta.append({"k": k, "quads": [szene.wahres_quad(Hw, n).tolist() for n in (0, 1)]})
    # 2) Woerterbuecher
    for cv_name in WOERTERBUECHER:
        d = cv2.aruco.getPredefinedDictionary(getattr(cv2.aruco, cv_name))
        streifen = np.full((300, 1000), 255, np.uint8)
        for i in range(8):
            streifen[100:190, 20 + i * 120:110 + i * 120] = cv2.aruco.generateImageMarker(d, i, 90)
        rgba(cv2.GaussianBlur(streifen, (3, 3), 0.7), f"wb_{cv_name}.rgba")
    # 3) Beispielbild der Seite (so wie der Browser es dekodiert)
    bsp = cv2.imread(os.path.join(HIER, "..", "..", "web", "beispiel.jpg"))
    rgba(bsp, "beispiel.rgba")
    json.dump({"fahrt": meta, "fahrt_groesse": [960, 540], "anzeige_groesse": [szene.W, szene.H],
               "f_wahr": szene.F_WAHR, "laenge_wahr": szene.LAENGE_WAHR,
               "breiten": [b["breite"] for b in szene.BAHNSTEIGE],
               "woerterbuecher": WOERTERBUECHER, "beispiel_groesse": [bsp.shape[1], bsp.shape[0]]},
              open(os.path.join(DATEN, "meta.json"), "w"), indent=1)
    print("Testdaten in", os.path.relpath(DATEN))
