"""Synthetische Testszene: H0-Anlage mit zwei Bahnsteigen und ArUco-Markern 0-7,
gerendert mit einer bekannten Kamera (Brennweite F_WAHR). Wird von den Python-Tests
und vom Testdaten-Generator fuer die Web-Tests benutzt."""
import math
import os
import sys

import cv2
import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
import bahnsteig_ar as ar  # noqa: E402

PX = 4                       # Texturpixel pro mm
TW, TH = 800, 500            # Anlagengroesse in mm
F_WAHR = 950.0
W, H = 1280, 720
K = np.array([[F_WAHR, 0, W / 2], [0, F_WAHR, H / 2], [0, 0, 1.0]])
WOERTERBUCH = "DICT_ARUCO_ORIGINAL"

# Bahnsteige wie auf der echten Anlage: 70 mm und 37 mm breit, Marker mittig an den Enden
BAHNSTEIGE = [
    dict(y=180.0, breite=70.0, von=130.0, bis=570.0),
    dict(y=355.0, breite=37.0, von=130.0, bis=570.0),
]
LAENGE_WAHR = 440.0
# Marker: id -> (x_mm, y_mm, Drehung in Grad) - bewusst unterschiedlich gedreht
MARKER = {0: (130, 180, 0), 1: (570, 180, 0), 2: (130, 355, 30), 3: (570, 355, 90),
          4: (40, 40, 0), 5: (760, 40, 0), 6: (40, 460, 0), 7: (760, 460, 0)}


def textur(woerterbuch=WOERTERBUCH):
    d = cv2.aruco.getPredefinedDictionary(getattr(cv2.aruco, woerterbuch))
    t = np.full((TH * PX, TW * PX, 3), (70, 110, 80), np.uint8)
    rausch = np.random.default_rng(1).integers(-12, 12, t.shape[:2])
    t = np.clip(t.astype(int) + rausch[..., None], 0, 255).astype(np.uint8)

    def rechteck(x0, y0, x1, y1, farbe):
        cv2.rectangle(t, (int(x0 * PX), int(y0 * PX)), (int(x1 * PX), int(y1 * PX)), farbe, -1)

    for yc in (120, 265, 420):                                  # Gleise
        rechteck(20, yc - 18, 780, yc + 18, (95, 105, 115))
        for dy in (-8, 8):
            rechteck(20, yc + dy - 1, 780, yc + dy + 1, (170, 170, 175))
    for b in BAHNSTEIGE:
        rechteck(b["von"] - 20, b["y"] - b["breite"] / 2, b["bis"] + 20, b["y"] + b["breite"] / 2, (175, 180, 185))
    s = 30 * PX
    for mid, (x, y, rot) in MARKER.items():
        m = cv2.aruco.generateImageMarker(d, mid, s)
        pad = 8 * PX
        gross = np.full((s + 2 * pad, s + 2 * pad), 255, np.uint8)
        gross[pad:pad + s, pad:pad + s] = m
        if rot:
            M = cv2.getRotationMatrix2D((gross.shape[1] / 2, gross.shape[0] / 2), rot, 1.0)
            gross = cv2.warpAffine(gross, M, gross.shape[::-1], flags=cv2.INTER_LINEAR, borderValue=255)
        cx, cy, hh = int(x * PX), int(y * PX), gross.shape[0] // 2
        t[cy - hh:cy - hh + gross.shape[0], cx - hh:cx - hh + gross.shape[1]] = gross[..., None]
    return t


def kamera_pose(k):
    """Leicht wackelnde Kamera, ca. 45 Grad schraeg von oben."""
    ziel = np.array([400.0, 265.0, 0.0])
    cam = np.array([400.0 + 60 * math.sin(k * 0.05), 265 + 650 + 20 * math.cos(k * 0.07), -650.0])
    f = ziel - cam
    f /= np.linalg.norm(f)
    x = np.cross([0, 1, 0], f)
    x /= np.linalg.norm(x)
    R = np.array([x, np.cross(f, x), f])
    return R, -R @ cam


def render(tex, k, verdecke=()):
    """Bild k der Kamerafahrt; verdecke = Marker-IDs, ueber die eine 'Hand' gelegt wird."""
    R, t = kamera_pose(k)
    Hw = K @ np.column_stack([R[:, 0], R[:, 1], t])            # Anlage (mm) -> Bild
    S = np.diag([PX, PX, 1.0])
    img = cv2.warpPerspective(tex, Hw @ np.linalg.inv(S), (W, H), flags=cv2.INTER_AREA,
                              borderValue=(40, 40, 40))
    for mid in verdecke:
        x, y, _ = MARKER[mid]
        p = Hw @ [x, y, 1]
        cv2.circle(img, (int(p[0] / p[2]), int(p[1] / p[2])), 45, (60, 80, 120), -1)
    img = cv2.GaussianBlur(img, (3, 3), 0.8)
    rausch = np.random.default_rng(k).normal(0, 3, img.shape)
    return np.clip(img.astype(np.int16) + rausch, 0, 255).astype(np.uint8), Hw


def wahres_quad(Hw, nr):
    """Bildecken von Bahnsteig nr in der Reihenfolge des Programms (Anfang rechts, Ende rechts, Ende links, Anfang links)."""
    b = BAHNSTEIGE[nr]
    a, e, hb = np.array([b["von"], b["y"]]), np.array([b["bis"], b["y"]]), b["breite"] / 2
    u = (e - a) / np.linalg.norm(e - a)
    n = np.array([-u[1], u[0]])
    return ar.anwenden(Hw, [a - n * hb, e - n * hb, e + n * hb, a + n * hb])


def eckfehler(quad, wahr):
    """Groesste Eckenabweichung in Pixeln (Orientierung der Querachse egal)."""
    return min(np.linalg.norm(quad - wahr, axis=1).max(),
               np.linalg.norm(quad - wahr[[3, 2, 1, 0]], axis=1).max())


def verdeckte(k):
    """Ablauf der Testfahrt: Marker 1 zeitweise verdeckt, spaeter Bahnsteig 2 komplett."""
    if 60 <= k < 90:
        return [1]
    if 110 <= k < 130:
        return [2, 3]
    return []
