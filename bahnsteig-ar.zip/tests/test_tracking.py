"""Tracking-Test an der synthetischen Szene: Bahnsteigecken, Laenge, Brennweite,
Verhalten bei verdeckten Markern. Aufruf: python -m pytest tests"""
import numpy as np
import pytest

import szene
from szene import ar

BILDER = 160


@pytest.fixture(scope="module")
def lauf():
    tex = szene.textur()
    app = ar.App(szene.W, szene.H, woerterbuch=szene.WOERTERBUCH, kalibrierdatei=None, seed=3)
    for b, s in zip(app.steige, szene.BAHNSTEIGE):          # Breiten wie in der Szene
        b.W = s["breite"]
    fehler = {0: [], 1: []}
    zeiten = []
    import time
    for k in range(BILDER):
        img, Hw = szene.render(tex, k, szene.verdeckte(k))
        t0 = time.perf_counter()
        aus = app.verarbeite(img, 1 / 15)
        zeiten.append(time.perf_counter() - t0)
        for i, b in enumerate(app.steige):
            if b.quad is not None and b.sichtbar(app.zeit):
                fehler[i].append(szene.eckfehler(b.quad, szene.wahres_quad(Hw, i)))
    return app, fehler, zeiten, aus


def test_woerterbuch(lauf):
    app = lauf[0]
    assert app.erk.name == szene.WOERTERBUCH


def test_bahnsteigecken_genau(lauf):
    _, fehler, _, _ = lauf
    for i in (0, 1):
        assert len(fehler[i]) == BILDER, "Bahnsteig muss durchgehend verfolgt werden, auch bei verdeckten Markern"
        assert np.median(fehler[i]) < 3.0
        assert max(fehler[i]) < 6.0


def test_laenge(lauf):
    app = lauf[0]
    for b in app.steige:
        assert abs(b.Lp - szene.LAENGE_WAHR) / szene.LAENGE_WAHR < 0.05


def test_brennweite_geschaetzt(lauf):
    app = lauf[0]
    assert app.kam.quelle() == "geschaetzt"
    assert abs(app.kam.f() - szene.F_WAHR) / szene.F_WAHR < 0.10


def test_simulation_laeuft(lauf):
    app, _, _, aus = lauf
    assert sum(b.sim.anzahl() for b in app.steige) > 0
    assert aus.shape == (szene.H, szene.W, 3)


def test_automatische_woerterbuchsuche():
    tex = szene.textur("DICT_4X4_50")
    app = ar.App(szene.W, szene.H, woerterbuch=None, kalibrierdatei=None, seed=1)
    for k in range(5):
        app.verarbeite(szene.render(tex, k)[0], 1 / 15)
    assert app.erk.name == "DICT_4X4_50"
