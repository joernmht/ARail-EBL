"""Kalibrierung nur mit einzelnen 30-mm-Markern: simulierte Ansichten durch ein
verzeichnendes Objektiv (f = 950 px, k1 = -0.25) muessen wiedergefunden werden."""
import math
import os
import sys

import cv2
import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
import kalibrierung as kal  # noqa: E402

W, H = 1280, 720
K = np.array([[950.0, 0, 640], [0, 950.0, 360], [0, 0, 1]])
D = np.array([-0.25, 0.08, 0, 0, 0])


def ansichten(n, rauschen, rng):
    out = []
    while len(out) < n:
        achse = rng.normal(size=3)
        achse /= np.linalg.norm(achse)
        rvec = achse * math.radians(rng.uniform(15, 60))
        z = rng.uniform(250, 600)
        u, v = rng.uniform(40, W - 40), rng.uniform(40, H - 40)
        t = np.array([(u - 640) / 950 * z, (v - 360) / 950 * z, z])
        p, _ = cv2.projectPoints(kal.objektpunkte(), rvec, t, K, D)
        p = p.reshape(4, 2) + rng.normal(0, rauschen, (4, 2))
        kante = np.linalg.norm(np.roll(p, -1, 0) - p, axis=1).min()
        if p.min() > 0 and p[:, 0].max() < W and p[:, 1].max() < H and kante >= kal.MIN_KANTE_PX:
            out.append(p)
    return out


def test_kalibrierung_findet_brennweite_und_verzeichnung():
    rng = np.random.default_rng(1)
    rms, Kx, dx = kal.berechne(ansichten(80, 0.2, rng), (W, H))
    assert rms < 0.5
    assert abs(Kx[0, 0] - 950) / 950 < 0.05
    assert abs(dx[0] - D[0]) < 0.03
