#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Bahnsteig-AR - Personenstroeme auf der Modellbahn mit ArUco-Markern
===================================================================

Aufbau
  * Bahnsteig 1 liegt zwischen Marker 0 und 1, Bahnsteig 2 zwischen Marker 2 und 3.
  * Marker: 30 mm x 30 mm (gemessen am schwarzen Quadrat, ohne weissen Rand).
  * ArUco-Woerterbuch: Original ArUco (Einstellung WOERTERBUCH). Mit --woerterbuch auto
    werden 4x4, 5x5, 6x6, 7x7, Original, MIP 36h12 und AprilTag 36h11 durchprobiert.
  * Die Marker duerfen beliebig gedreht liegen.

Ohne Kalibrierung
  Die Bahnsteigflaeche wird direkt aus den Markerecken berechnet (Homographie).
  Dafuer braucht es keine Kamerakalibrierung. Nur fuer die senkrecht stehenden
  Figuren wird eine Brennweite gebraucht - die schaetzt das Programm selbst aus
  der Perspektive der Marker. Wer es genauer will (z. B. Weitwinkel-Webcam mit
  starker Verzeichnung), startet einmal kalibrierung.py - auch das nur mit den
  Markern, ohne Kalibrierboard.

Installation
  pip install opencv-contrib-python numpy

Start
  python bahnsteig_ar.py                  Webcam 0
  python bahnsteig_ar.py --kamera 1       andere Kamera
  python bahnsteig_ar.py --kamera film.mp4
  python bahnsteig_ar.py --woerterbuch auto          (Woerterbuch automatisch suchen)

Tasten
  1 / 2       Zug faehrt sofort in Bahnsteig 1 / 2 ein
  V           Verspaetung an/aus (keine Zuege, Stimmung kippt ins Rote)
  + / -       mehr / weniger Andrang
  S           Laufspuren an/aus
  I           Infoschilder an/aus
  M           Markerumrisse an/aus
  , / .       Brennweite kleiner / groesser (Figuren kippen -> nachjustieren)
  R           Bahnsteige leeren
  F           Vollbild
  Leertaste   Pause
  Q / Esc     Beenden
"""

import argparse
import math
import os
import time
from collections import deque

import cv2
import numpy as np

# =============================================================================
# EINSTELLUNGEN
# =============================================================================

MARKER_GROESSE_MM = 30.0     # Kantenlaenge des schwarzen Marker-Quadrats

WOERTERBUCH = "DICT_ARUCO_ORIGINAL"   # "auto" = automatisch suchen

MASSSTAB = 87                # H0 = 87, TT = 120, N = 160, Z = 220, 0 = 45, 1 = 32

# Je Bahnsteig zwei Marker-IDs (Anfang, Ende).
#   breite_mm      Breite des Bahnsteigs im Modell
#   versatz_mm     Bahnsteigmitte liegt seitlich neben der Linie Markermitte -> Markermitte
#                  (positiv = links, von oben gesehen und vom ersten zum zweiten Marker geschaut)
#   ueberstand_mm  Bahnsteig reicht so weit ueber die Markermitten hinaus (negativ = kuerzer)
#   gleis          an welcher Kante Zuege halten: "links", "rechts" oder "beide"
BAHNSTEIGE = [
    dict(name="Bahnsteig 1", marker=(0, 1), breite_mm=70.0, versatz_mm=0.0,
         ueberstand_mm=0.0, gleis="beide"),
    dict(name="Bahnsteig 2", marker=(2, 3), breite_mm=37.0, versatz_mm=0.0,
         ueberstand_mm=0.0, gleis="beide"),
]

ZEITRAFFER = 2.0             # Simulation laeuft so viel schneller als die Echtzeit
GRUNDANDRANG = 0.5           # neue Fahrgaeste pro Sekunde auf 25 m Bahnsteig (Vorbildmass)
MAX_PERSONEN = 140           # pro Bahnsteig
ZUGTAKT_S = (50.0, 90.0)     # Abstand der Zuege (Simulationssekunden)
HALTEZEIT_ZUG_S = 24.0       # Aufenthalt am Bahnsteig (Simulationssekunden)
ZUG_ZEICHNEN = True          # virtuellen Zug einblenden
SPUREN_ZEIGEN = True         # Laufspuren = sichtbare Personenstroeme
TRACKING_HALTEN_S = 1.5      # so lange bleibt die Einblendung, wenn alle Marker verdeckt sind
KALIBRIERDATEI = "kamera_kalibrierung.npz"
FENSTERNAME = "Bahnsteig-AR"

# Woerterbuecher, die automatisch ausprobiert werden
WOERTERBUECHER = ["DICT_4X4_50", "DICT_5X5_50", "DICT_6X6_50", "DICT_7X7_50",
                  "DICT_ARUCO_ORIGINAL", "DICT_ARUCO_MIP_36h12", "DICT_APRILTAG_36h11"]

# =============================================================================
# Hilfsfunktionen
# =============================================================================

_h = MARKER_GROESSE_MM / 2.0
# Markerecken in mm (Reihenfolge wie OpenCV: oben links, oben rechts, unten rechts, unten links)
MARKER_ECKEN_MM = np.array([[-_h, _h], [_h, _h], [_h, -_h], [-_h, -_h]], np.float32)


def txt(s):
    """cv2.putText kann keine Umlaute."""
    for a, b in (("ä", "ae"), ("ö", "oe"), ("ü", "ue"), ("Ä", "Ae"), ("Ö", "Oe"),
                 ("Ü", "Ue"), ("ß", "ss"), ("–", "-")):
        s = s.replace(a, b)
    return s


_ROT = np.array([50.0, 50.0, 230.0])
_GELB = np.array([30.0, 205.0, 245.0])
_GRUEN = np.array([70.0, 195.0, 40.0])


def stimmungsfarbe(m):
    """0 = schlechte Laune (rot) ... 1 = gute Laune (gruen), BGR."""
    m = min(max(float(m), 0.0), 1.0)
    if m < 0.5:
        c = _ROT + (_GELB - _ROT) * (m / 0.5)
    else:
        c = _GELB + (_GRUEN - _GELB) * ((m - 0.5) / 0.5)
    return tuple(int(x) for x in c)


def anwenden(H, pts):
    pts = np.asarray(pts, np.float64).reshape(-1, 1, 2)
    return cv2.perspectiveTransform(pts, H).reshape(-1, 2)


def dehom(v):
    return v[:2] / v[2]


def links_von(u):
    return np.array([-u[1], u[0]])


def jacobi(H):
    """Ableitung der Homographie im Markermittelpunkt (mm -> Pixel)."""
    h = H / H[2, 2]
    return np.array([[h[0, 0] - h[0, 2] * h[2, 0], h[0, 1] - h[0, 2] * h[2, 1]],
                     [h[1, 0] - h[1, 2] * h[2, 0], h[1, 1] - h[1, 2] * h[2, 1]]])


def aehnlichkeit(von, nach, pts):
    """Verschiebung + Drehung + Massstab (kleinste Quadrate) von 'von' nach 'nach', angewandt auf pts."""
    mv, mn = von.mean(0), nach.mean(0)
    zv = (von - mv) @ np.array([1, 1j])
    zn = (nach - mn) @ np.array([1, 1j])
    a = np.vdot(zv, zn) / np.vdot(zv, zv)
    z = ((np.asarray(pts) - mv) @ np.array([1, 1j])) * a
    return np.c_[z.real, z.imag] + mn


_SHIFT = 2
_SK = 1 << _SHIFT


def ipa(uv):
    """Viele Punkte auf einmal in Festkomma-Pixel (fuer cv2 mit shift)."""
    return np.rint(np.asarray(uv) * _SK).astype(np.int32)


def textkasten(img, x, y, zeilen, skala=0.5, anker="ol", balken=None, farben=None):
    """Halbtransparenter Kasten mit Textzeilen. anker: 'ol' oben links, 'um' unten Mitte."""
    if not zeilen:
        return
    h, w = img.shape[:2]
    zeilen = [txt(z) for z in zeilen]
    dicke = 1
    groessen = [cv2.getTextSize(z, cv2.FONT_HERSHEY_SIMPLEX, skala, dicke)[0] for z in zeilen]
    zh = int(max(g[1] for g in groessen) * 1.7) + 2
    pad = int(8 * skala / 0.5)
    bw = max(g[0] for g in groessen) + 2 * pad
    bh = zh * len(zeilen) + 2 * pad - int(zh * 0.3)
    bar_h = int(8 * skala / 0.5)
    if balken is not None:
        bw = max(bw, int(150 * skala / 0.5))
        bh += bar_h + pad // 2
    if anker == "um":
        x0, y0 = int(x - bw / 2), int(y - bh)
    elif anker == "ur":
        x0, y0 = int(x - bw), int(y - bh)
    elif anker == "ul":
        x0, y0 = int(x), int(y - bh)
    else:
        x0, y0 = int(x), int(y)
    x0 = max(0, min(w - bw, x0))
    y0 = max(0, min(h - bh, y0))
    roi = img[y0:y0 + bh, x0:x0 + bw]
    if roi.size == 0:
        return
    roi[:] = (roi * 0.35 + np.array([25, 25, 25]) * 0.65).astype(np.uint8)
    for i, z in enumerate(zeilen):
        col = farben[i] if farben and farben[i] else (240, 240, 240)
        cv2.putText(img, z, (x0 + pad, y0 + pad + groessen[i][1] + i * zh),
                    cv2.FONT_HERSHEY_SIMPLEX, skala, col, dicke, cv2.LINE_AA)
    if balken is not None:
        by = y0 + bh - pad - bar_h
        bx1 = x0 + bw - pad
        cv2.rectangle(img, (x0 + pad, by), (bx1, by + bar_h), (90, 90, 90), -1)
        bx = x0 + pad + int((bx1 - x0 - pad) * min(max(balken, 0), 1))
        cv2.rectangle(img, (x0 + pad, by), (bx, by + bar_h), stimmungsfarbe(balken), -1)


# =============================================================================
# Kamera und Markererkennung
# =============================================================================

def kamera_oeffnen(quelle, breite=1280, hoehe=720):
    if isinstance(quelle, int):
        backend = cv2.CAP_DSHOW if os.name == "nt" else cv2.CAP_ANY
        cap = cv2.VideoCapture(quelle, backend)
        cap.set(cv2.CAP_PROP_FOURCC, cv2.VideoWriter_fourcc(*"MJPG"))
        cap.set(cv2.CAP_PROP_FRAME_WIDTH, breite)
        cap.set(cv2.CAP_PROP_FRAME_HEIGHT, hoehe)
    else:
        cap = cv2.VideoCapture(quelle)
    return cap


def _detektor_parameter():
    try:
        p = cv2.aruco.DetectorParameters()
    except AttributeError:
        p = cv2.aruco.DetectorParameters_create()
    p.cornerRefinementMethod = cv2.aruco.CORNER_REFINE_SUBPIX
    p.cornerRefinementWinSize = 3      # kleines Fenster: die Marker sind im Bild nur klein
    return p


class MarkerErkennung:
    """Findet ArUco-Marker; probiert beim Start alle gaengigen Woerterbuecher durch."""

    def __init__(self, name=None, ids=range(8)):
        self.params = _detektor_parameter()
        self.ids = set(ids)
        self.kandidaten = [n for n in WOERTERBUECHER if hasattr(cv2.aruco, n)]
        self.stimmen = {n: 0 for n in self.kandidaten}
        self._det = {}
        self.name = None
        if name:
            if not hasattr(cv2.aruco, name):
                raise SystemExit(f"Unbekanntes Woerterbuch: {name}")
            self.name = name

    def _detektor(self, name):
        if name not in self._det:
            d = cv2.aruco.getPredefinedDictionary(getattr(cv2.aruco, name))
            if hasattr(cv2.aruco, "ArucoDetector"):            # OpenCV >= 4.7
                self._det[name] = cv2.aruco.ArucoDetector(d, self.params).detectMarkers
            else:                                               # aeltere Versionen
                self._det[name] = lambda g, d=d: cv2.aruco.detectMarkers(g, d, parameters=self.params)
        return self._det[name]

    def _finde(self, name, grau):
        ecken, ids, _ = self._detektor(name)(grau)
        erg = {}
        if ids is not None:
            for c, i in zip(ecken, ids.flatten()):
                i = int(i)
                if i in self.ids and i not in erg:
                    erg[i] = c.reshape(4, 2).astype(np.float64)
        return erg

    def erkenne(self, grau):
        """-> {id: 4x2 Eckpunkte in Pixeln}"""
        if self.name:
            return self._finde(self.name, grau)
        bestes, bester = {}, None
        for n in self.kandidaten:
            e = self._finde(n, grau)
            if len(e) > len(bestes):
                bestes, bester = e, n
        if bester:
            self.stimmen[bester] += len(bestes)
            if self.stimmen[bester] >= 6:
                self.name = bester
                print(f"ArUco-Woerterbuch erkannt: {bester}")
        return bestes


def brennweite_aus_homographie(H, cx, cy):
    """Brennweite aus einer Ebenen-Homographie (Hauptpunkt in Bildmitte, quadratische Pixel).
    Liefert (f, Neigung der Ebene in Grad) oder None."""
    G = np.array([[1, 0, -cx], [0, 1, -cy], [0, 0, 1.0]]) @ H
    h1, h2 = G[:, 0], G[:, 1]
    a1 = h1[0] * h2[0] + h1[1] * h2[1]
    b1 = h1[2] * h2[2]
    a2 = h1[0] ** 2 + h1[1] ** 2 - h2[0] ** 2 - h2[1] ** 2
    b2 = h1[2] ** 2 - h2[2] ** 2
    nenner = a1 * a1 + a2 * a2
    if nenner <= 0:
        return None
    x = -(a1 * b1 + a2 * b2) / nenner          # x = 1 / f^2
    if x <= 0:
        return None
    f = 1.0 / math.sqrt(x)
    r1 = np.array([h1[0] / f, h1[1] / f, h1[2]])
    r2 = np.array([h2[0] / f, h2[1] / f, h2[2]])
    n = np.cross(r1, r2)
    nn = np.linalg.norm(n)
    if nn == 0:
        return None
    neigung = math.degrees(math.acos(min(1.0, abs(n[2]) / nn)))
    return f, neigung


def lage_zueinander(Ha, Hb):
    """Lage von Marker b im Markersystem a (beide in derselben Ebene), ohne Kalibrierung.
    Entlang der Verbindungslinie ist die Perspektive eine 1D-Projektivitaet; daraus folgt
    Abstand = Pixelabstand / sqrt(Massstab_a * Massstab_b).
    Rueckgabe: Abstand (mm), Richtung in a, Richtung in b (Einheitsvektoren) oder None."""
    ca, cb = dehom(Ha[:, 2]), dehom(Hb[:, 2])
    D = float(np.linalg.norm(cb - ca))
    if D < 1.0:
        return None
    r = (cb - ca) / D
    Ja, Jb = jacobi(Ha), jacobi(Hb)
    ua, ub = np.linalg.solve(Ja, r), np.linalg.solve(Jb, r)
    ua /= np.linalg.norm(ua)
    ub /= np.linalg.norm(ub)
    L = D / math.sqrt(np.linalg.norm(Ja @ ua) * np.linalg.norm(Jb @ ub))
    return L, ua, ub


def brennweite_aus_anlage(marker, cx, cy):
    """Brennweite aus allen sichtbaren Markern gemeinsam (lange Basis statt 30 mm)."""
    ids = sorted(marker)
    if len(ids) < 3:
        return None
    r = ids[0]
    Hr, er = marker[r]
    ebene, bild = [MARKER_ECKEN_MM.astype(np.float64)], [er]
    for m in ids[1:]:
        Hm, em = marker[m]
        z = lage_zueinander(Hr, Hm)
        if z is None:
            continue
        L, ur, um = z
        phi = math.atan2(ur[1], ur[0]) - math.atan2(um[1], um[0])
        Rm = np.array([[math.cos(phi), -math.sin(phi)], [math.sin(phi), math.cos(phi)]])
        ebene.append(L * ur + MARKER_ECKEN_MM.astype(np.float64) @ Rm.T)
        bild.append(em)
    if len(ebene) < 3:
        return None
    P, B = np.vstack(ebene), np.vstack(bild)
    if math.sqrt(max(np.linalg.eigvalsh(np.cov(P.T))[0], 0.0)) < 40.0:
        return None                                # Marker liegen fast auf einer Linie
    H, _ = cv2.findHomography(P, B, 0)
    if H is None:
        return None
    return brennweite_aus_homographie(H, cx, cy)


class Kamera:
    """Kameramodell: aus Kalibrierdatei, sonst Lochkamera mit geschaetzter Brennweite."""

    def __init__(self, breite, hoehe, datei=KALIBRIERDATEI):
        self.w, self.h = breite, hoehe
        self.K_kal = None
        self.dist = None
        self.f_manuell = None
        self.f_auto = None
        self.schaetzungen = deque(maxlen=900)
        self._n = 0
        if datei and os.path.exists(datei):
            d = np.load(datei)
            K = d["K"].astype(np.float64).copy()
            gw, gh = [float(v) for v in d["bildgroesse"]]
            sx, sy = breite / gw, hoehe / gh
            if abs(sx - sy) > 0.02:
                print(f"Kalibrierung {datei} passt nicht zum Seitenverhaeltnis - wird ignoriert.")
            else:
                K[0, 0] *= sx
                K[0, 2] *= sx
                K[1, 1] *= sy
                K[1, 2] *= sy
                self.K_kal = K
                self.dist = d["dist"].astype(np.float64).ravel()
                print(f"Kalibrierung geladen: f = {K[0, 0]:.0f} px")

    @property
    def kalibriert(self):
        return self.K_kal is not None

    def f(self):
        if self.kalibriert:
            return float(self.K_kal[0, 0])
        if self.f_manuell:
            return self.f_manuell
        if self.f_auto:
            return self.f_auto
        return 0.8 * self.w

    def quelle(self):
        if self.kalibriert:
            return "kalibriert"
        if self.f_manuell:
            return "manuell"
        if self.f_auto:
            return "geschaetzt"
        return "Startwert"

    def K(self):
        if self.kalibriert:
            return self.K_kal
        f = self.f()
        return np.array([[f, 0, self.w / 2.0], [0, f, self.h / 2.0], [0, 0, 1.0]])

    def entzerre(self, pts):
        if self.dist is None:
            return pts
        p = cv2.undistortPoints(pts.reshape(-1, 1, 2), self.K_kal, self.dist, P=self.K_kal)
        return p.reshape(-1, 2)

    def lerne(self, marker):
        """Sammelt Brennweiten-Schaetzungen aus der Perspektive aller sichtbaren Marker."""
        if self.kalibriert or self.f_manuell:
            return
        r = brennweite_aus_anlage(marker, self.w / 2.0, self.h / 2.0)
        if r is None:
            return
        f, neigung = r
        if 15.0 <= neigung <= 80.0 and 0.25 * self.w < f < 5.0 * self.w:
            self.schaetzungen.append(f)

    def aktualisiere(self):
        self._n += 1
        if len(self.schaetzungen) >= 15 and (self.f_auto is None or self._n % 10 == 0):
            self.f_auto = float(np.median(self.schaetzungen))

    def projiziere(self, X):
        """Punkte im Kamerasystem (N x 3) -> Pixel (N x 2)."""
        if self.dist is None:
            K = self.K()
            Z = np.maximum(X[:, 2], 1e-3)
            return np.c_[K[0, 0] * X[:, 0] / Z + K[0, 2], K[1, 1] * X[:, 1] / Z + K[1, 2]]
        p, _ = cv2.projectPoints(X.reshape(-1, 1, 3), np.zeros(3), np.zeros(3), self.K_kal, self.dist)
        return p.reshape(-1, 2)


def pose_aus_homographie(H, K):
    """Ebene -> Kamera. Rueckgabe A (3x3), n (Normale nach oben):
    Punkt (s, t, z) auf/ueber der Ebene liegt im Kamerasystem bei A @ (s, t, 1) + z * n."""
    M = np.linalg.solve(K, H)
    lam = 2.0 / (np.linalg.norm(M[:, 0]) + np.linalg.norm(M[:, 1]))
    if M[2, 2] * lam < 0:
        lam = -lam
    A = M * lam
    n = np.cross(A[:, 0], A[:, 1])
    n /= np.linalg.norm(n)
    if np.dot(n, A[:, 2]) > 0:          # Normale soll zur Kamera zeigen
        n = -n
    return A, n


# =============================================================================
# Personensimulation (in Vorbild-Metern)
# =============================================================================

class Person:
    __slots__ = ("pos", "vel", "ziel", "zustand", "stimmung", "warte", "tempo",
                 "groesse", "spur", "spur_t", "verz", "schritt")

    def __init__(self, pos, ziel, zustand, stimmung, rng):
        self.pos = np.array(pos, dtype=float)
        self.vel = np.zeros(2)
        self.ziel = np.array(ziel, dtype=float)
        self.zustand = zustand          # kommt, wartet, steigt_ein, im_zug, geht
        self.stimmung = min(max(float(stimmung), 0.0), 1.0)
        self.warte = 0.0
        self.tempo = rng.uniform(1.0, 1.5)
        self.groesse = rng.uniform(1.62, 1.92)
        self.spur = deque(maxlen=12)
        self.spur_t = 0.0
        self.verz = 0.0
        self.schritt = rng.uniform(0, 2 * math.pi)


class Simulation:
    """Ein Bahnsteig: s = laengs (0..L), t = quer (-W/2..W/2), alles in Vorbild-Metern."""

    def __init__(self, gleis, rng):
        self.rng = rng
        self.seiten = {"links": [1], "rechts": [-1]}.get(gleis, [1, -1])
        self.L, self.W = 25.0, 4.3
        self.personen = []
        self.t = 0.0
        self.phase = "weg"              # weg, einfahrt, haelt, ausfahrt
        self.timer = rng.uniform(10.0, 30.0)
        self.fahrt = 0.0
        self.seite = self.seiten[0]
        self.verspaetung = False
        self.war_verspaetet = False
        self.andrang = 1.0
        self.wellen_phase = rng.uniform(0, 2 * math.pi)
        self.zu, self.ab = deque(), deque()

    # ---- Geometrie -------------------------------------------------------
    def setze_masse(self, L, W):
        self.L, self.W = max(L, 3.0), max(W, 1.5)

    def tueren(self):
        n = max(2, int(round(self.L / 7.0)))
        return np.linspace(0.1 * self.L, 0.9 * self.L, n)

    def _zugang(self):
        r, W = self.rng.random(), self.W
        if r < 0.35:
            return np.array([0.3, self.rng.uniform(-0.25, 0.25) * W])
        if r < 0.70:
            return np.array([self.L - 0.3, self.rng.uniform(-0.25, 0.25) * W])
        return np.array([0.5 * self.L + self.rng.uniform(-0.5, 0.5), self.rng.uniform(-0.1, 0.1) * W])

    def _ausgang(self, pos):
        W = self.W
        kand = np.array([[0.3, 0.0], [self.L - 0.3, 0.0], [0.5 * self.L, 0.0]])
        d = np.abs(kand[:, 0] - pos[0])
        g = np.exp(-d / 6.0)
        k = kand[self.rng.choice(3, p=g / g.sum())].copy()
        k[1] = self.rng.uniform(-0.2, 0.2) * W
        return k

    def _warteplatz(self):
        s = self.rng.uniform(0.06, 0.94) * self.L
        lo, hi = {(1,): (0.0, 0.38), (-1,): (-0.38, 0.0)}.get(tuple(self.seiten), (-0.38, 0.38))
        return np.array([s, self.rng.uniform(lo, hi) * self.W])

    def _tuerplatz(self, s):
        tu = self.tueren()
        st = tu[np.argmin(np.abs(tu - s))] + self.rng.uniform(-0.3, 0.3)
        return np.array([st, self.seite * (self.W / 2 - 0.15)])

    # ---- Kennzahlen ------------------------------------------------------
    def sichtbare(self):
        return [p for p in self.personen if p.zustand != "im_zug"]

    def anzahl(self):
        return sum(1 for p in self.personen if p.zustand != "im_zug")

    def stimmung(self):
        s = [p.stimmung for p in self.personen if p.zustand != "im_zug"]
        return float(np.mean(s)) if s else 1.0

    def welle(self):
        return 0.3 + 0.7 * (0.5 + 0.5 * math.sin(2 * math.pi * self.t / 180.0 + self.wellen_phase))

    def statustext(self):
        if self.phase == "weg":
            if self.verspaetung:
                return "Zug verspätet!"
            return f"Nächster Zug in {max(0.0, self.timer / ZEITRAFFER):.0f} s"
        return {"einfahrt": "Zug fährt ein", "haelt": "Zug hält - Ein- und Aussteigen",
                "ausfahrt": "Zug fährt ab"}[self.phase]

    def leeren(self):
        self.personen = []

    # ---- Zug -------------------------------------------------------------
    def einfahrt(self):
        if self.phase == "weg":
            self.phase, self.fahrt = "einfahrt", 0.0
            self.seite = self.seiten[int(self.rng.integers(len(self.seiten)))]

    def _zug(self, dt):
        if self.phase == "weg":
            if not self.verspaetung:
                self.timer -= dt
                if self.timer <= 0:
                    self.einfahrt()
        elif self.phase == "einfahrt":
            self.fahrt += dt / 6.0
            if self.fahrt >= 1.0:
                self.phase, self.timer = "haelt", HALTEZEIT_ZUG_S
                self._tueren_auf()
        elif self.phase == "haelt":
            self.timer -= dt
            if self.timer <= 0:
                self.phase, self.fahrt = "ausfahrt", 0.0
                self._tueren_zu()
        elif self.phase == "ausfahrt":
            self.fahrt += dt / 6.0
            if self.fahrt >= 1.0:
                self.phase = "weg"
                self.timer = self.rng.uniform(*ZUGTAKT_S)

    def _einsteigen(self, p, verz=None):
        p.zustand = "steigt_ein"
        p.verz = self.rng.uniform(0.3, 6.0) if verz is None else verz
        p.ziel = self._tuerplatz(p.pos[0])
        p.stimmung = min(1.0, p.stimmung + 0.15)          # endlich!

    def _tueren_auf(self):
        rng = self.rng
        n = rng.poisson(2 + 6 * self.andrang * self.welle() * self.L / 25.0)
        tu = self.tueren()
        for _ in range(n):
            if len(self.personen) >= MAX_PERSONEN:
                break
            s = tu[int(rng.integers(len(tu)))] + rng.uniform(-0.4, 0.4)
            st = rng.uniform(0.6, 0.92) - (0.35 if self.war_verspaetet else 0.0)
            p = Person((s, self.seite * (self.W / 2 - 0.2)), (0, 0), "im_zug", st, rng)
            p.verz = rng.uniform(0.0, 7.0)
            p.ziel = self._ausgang(p.pos)
            self.personen.append(p)
        anteil = 1.0 if len(self.seiten) == 1 else 0.6
        for p in self.personen:
            if p.zustand in ("wartet", "kommt") and rng.random() < anteil:
                self._einsteigen(p)
        self.war_verspaetet = False

    def _tueren_zu(self):
        for p in self.personen:
            if p.zustand == "steigt_ein":                  # Zug verpasst
                p.zustand = "wartet"
                p.ziel = p.pos.copy()
                p.stimmung = max(0.0, p.stimmung - 0.35)
            elif p.zustand == "im_zug":
                p.verz = 0.0

    # ---- Zeitschritt -----------------------------------------------------
    def schritt(self, dt_echt):
        dt = min(dt_echt, 0.1) * ZEITRAFFER
        if dt <= 0:
            return
        self.t += dt
        if self.verspaetung:
            self.war_verspaetet = True
        rate = GRUNDANDRANG * self.andrang * self.welle() * self.L / 25.0
        for _ in range(self.rng.poisson(rate * dt)):
            if len(self.personen) >= MAX_PERSONEN:
                break
            st = self.rng.uniform(0.62, 0.95) - (0.3 if self.verspaetung else 0.0)
            self.personen.append(Person(self._zugang(), self._warteplatz(), "kommt", st, self.rng))
            self.zu.append(self.t)
        self._zug(dt)
        self._bewegen(dt)
        for q in (self.zu, self.ab):
            while q and q[0] < self.t - 60.0:
                q.popleft()

    def _bewegen(self, dt):
        rng, L, W = self.rng, self.L, self.W
        for p in self.personen:
            if p.zustand == "im_zug":
                p.verz -= dt
                if p.verz <= 0:
                    p.zustand = "geht"
                    self.zu.append(self.t)
        aktiv = self.sichtbare()
        n = len(aktiv)
        if n == 0:
            return
        P = np.array([p.pos for p in aktiv])
        D = P[:, None, :] - P[None, :, :]
        d = np.sqrt((D ** 2).sum(-1)) + np.eye(n) * 1e6
        d = np.maximum(d, 1e-6)
        nachbarn = (d < 1.3).sum(1)
        R = 0.6
        gew = np.clip((R - d) / R, 0.0, None)
        abstoss = (gew[..., None] * D / d[..., None]).sum(1) * 1.4
        einzel = len(self.seiten) == 1
        weg = set()
        for i, p in enumerate(aktiv):
            dichte = max(0, int(nachbarn[i]) - 2)
            zu_ziel = p.ziel - p.pos
            dist = float(math.hypot(zu_ziel[0], zu_ziel[1]))
            laufen = p.zustand in ("kommt", "geht") or (p.zustand == "steigt_ein" and p.verz <= 0)
            if laufen:
                v = zu_ziel / max(dist, 1e-6) * p.tempo * min(1.0, dist / 0.8) / (1 + 0.12 * dichte)
                v = v + abstoss[i]
            else:
                v = zu_ziel * 0.6 + 0.7 * abstoss[i]
            p.vel += (v - p.vel) * min(1.0, 4.0 * dt)
            p.pos += p.vel * dt
            rand = 0.12 if p.zustand == "steigt_ein" else 0.22
            p.pos[0] = min(max(p.pos[0], 0.1), L - 0.1)
            p.pos[1] = min(max(p.pos[1], -W / 2 + rand), W / 2 - rand)
            tempo = math.hypot(p.vel[0], p.vel[1])
            p.schritt += tempo * dt * 5.0
            # Laufspur
            p.spur_t += dt
            if tempo > 0.3:
                if p.spur_t > 0.4:
                    p.spur.append(p.pos.copy())
                    p.spur_t = 0.0
            elif p.spur and p.spur_t > 0.3:
                p.spur.popleft()
                p.spur_t = 0.0
            # Zustaende
            if p.zustand == "kommt":
                if dist < 0.4:
                    if self.phase == "haelt" and self.timer > 6 and (einzel or rng.random() < 0.6):
                        self._einsteigen(p, verz=0.0)
                    else:
                        p.zustand = "wartet"
            elif p.zustand == "wartet":
                p.warte += dt
                if rng.random() < 0.04 * dt:              # von einem Bein aufs andere
                    p.ziel = p.ziel + rng.normal(0, 0.4, 2)
                    p.ziel[0] = min(max(p.ziel[0], 0.5), L - 0.5)
                    p.ziel[1] = min(max(p.ziel[1], -0.38 * W), 0.38 * W)
            elif p.zustand == "steigt_ein":
                if p.verz > 0:
                    p.verz -= dt
                elif dist < 0.35:
                    weg.add(id(p))
                    self.ab.append(self.t)
            elif p.zustand == "geht":
                if dist < 0.5:
                    weg.add(id(p))
                    self.ab.append(self.t)
            # Stimmung
            if p.zustand in ("kommt", "wartet"):
                r = (0.002 + 0.005 * dichte + (0.006 if p.warte > 60 else 0.0)
                     + (0.02 if self.verspaetung else 0.0))
                p.stimmung -= r * dt
            elif p.zustand == "steigt_ein":
                p.stimmung += 0.02 * dt
            else:
                p.stimmung += (0.008 - 0.004 * dichte) * dt
            p.stimmung = min(1.0, max(0.0, p.stimmung))
        if weg:
            self.personen = [p for p in self.personen if id(p) not in weg]


# =============================================================================
# Bahnsteig: Tracking + Zeichnen
# =============================================================================

def _ease(x):
    x = min(max(x, 0.0), 1.0)
    return x * x * (3 - 2 * x)


class Bahnsteig:
    def __init__(self, cfg, rng):
        self.name = cfg.get("name", "Bahnsteig")
        self.id_a, self.id_b = cfg["marker"]
        self.W = float(cfg.get("breite_mm", 50.0))
        self.versatz = float(cfg.get("versatz_mm", 0.0))
        self.ueber = float(cfg.get("ueberstand_mm", 0.0))
        self.sim = Simulation(cfg.get("gleis", "beide"), rng)
        self.Lp = None               # Bahnsteiglaenge im Modell (mm)
        self.quad = None             # geglaettete Bildecken
        self.referenz = None         # (Bahnsteigecken, {Marker-ID: Ecken}) zuletzt mit beiden Markern
        self.gesehen = set()
        self.zuletzt = -1e9
        self.H = None                # Bahnsteig (mm) -> Bild
        self.A = None
        self.n = None

    # ---- Tracking --------------------------------------------------------
    def _ecken_mm(self):
        W = self.W
        return np.array([[0, -W / 2], [self.Lp, -W / 2], [self.Lp, W / 2], [0, W / 2]], np.float32)

    def aktualisiere(self, marker, jetzt):
        """marker: {id: (Homographie Marker-mm -> Bild, 4x2 Bildecken)}"""
        A, B = marker.get(self.id_a), marker.get(self.id_b)
        self.gesehen = {i for i in (self.id_a, self.id_b) if i in marker}
        quad = None
        if A is not None and B is not None:
            HA, HB = A[0], B[0]
            z = lage_zueinander(HA, HB)
            if z is None:
                return
            L, uA, uB = z
            if not (1.2 * MARKER_GROESSE_MM < L < 5000):
                return
            nA, nB = links_von(uA), links_von(uB)
            e, dv, W = self.ueber, self.versatz, self.W
            pa = anwenden(HA, [-e * uA + (dv - W / 2) * nA, -e * uA + (dv + W / 2) * nA])
            pb = anwenden(HB, [e * uB + (dv - W / 2) * nB, e * uB + (dv + W / 2) * nB])
            quad = np.array([pa[0], pb[0], pb[1], pa[1]])
            Lp = L + 2 * e
            self.Lp = Lp if self.Lp is None else 0.85 * self.Lp + 0.15 * Lp
            # Momentaufnahme aller Marker fuer den Fall, dass spaeter einer verdeckt ist
            self.referenz = (quad.copy(), {i: m[1].copy() for i, m in marker.items()})
        elif self.referenz is not None:
            # Bahnsteigmarker verdeckt: die Ebene ueber alle anderen Marker weiterverfolgen
            q_alt, ecken_alt = self.referenz
            gemeinsam = [i for i in marker if i in ecken_alt]
            if len(gemeinsam) >= 2:
                von = np.vstack([ecken_alt[i] for i in gemeinsam])
                nach = np.vstack([marker[i][1] for i in gemeinsam])
                M, _ = cv2.findHomography(von, nach, 0)
                if M is not None:
                    quad = anwenden(M, q_alt)
            elif len(gemeinsam) == 1:
                i = gemeinsam[0]
                quad = aehnlichkeit(ecken_alt[i], marker[i][1], q_alt)
        if quad is None or self.Lp is None or not np.all(np.isfinite(quad)):
            return
        if not cv2.isContourConvex(quad.astype(np.float32).reshape(-1, 1, 2)):
            return
        if self.quad is None:
            self.quad = quad
        else:
            diff = float(np.max(np.linalg.norm(quad - self.quad, axis=1)))
            alpha = min(1.0, 0.25 + diff / 12.0)            # ruhig halten, aber schnell folgen
            self.quad = self.quad + alpha * (quad - self.quad)
        self.H = cv2.getPerspectiveTransform(self._ecken_mm(), self.quad.astype(np.float32))
        self.zuletzt = jetzt
        k = MASSSTAB / 1000.0
        self.sim.setze_masse(self.Lp * k, self.W * k)

    def sichtbar(self, jetzt):
        return self.H is not None and jetzt - self.zuletzt < TRACKING_HALTEN_S

    def status(self, jetzt):
        if self.Lp is None:
            return f"Marker {self.id_a} und {self.id_b} einmal gleichzeitig zeigen"
        if not self.sichtbar(jetzt):
            return "nicht im Bild"
        fehlt = [i for i in (self.id_a, self.id_b) if i not in self.gesehen]
        if not fehlt:
            return "ok"
        if len(fehlt) == 1:
            return f"Marker {fehlt[0]} verdeckt"
        return "Marker verdeckt - halte Position"

    def pose(self, K):
        self.A, self.n = pose_aus_homographie(self.H, K)

    def kamerapunkte(self, pts):
        """Vorbild-Meter (s, t, z) -> Kamerakoordinaten (mm)."""
        P = np.asarray(pts, float).reshape(-1, 3) * (1000.0 / MASSSTAB)
        A = self.A
        return P[:, :1] * A[:, 0] + P[:, 1:2] * A[:, 1] + A[:, 2] + P[:, 2:3] * self.n

    def projiziere(self, pts, kam):
        """Vorbild-Meter (s, t, z) -> Pixel, Tiefe."""
        X = self.kamerapunkte(pts)
        return kam.projiziere(X), X[:, 2]

    def _rand(self, kam, n=12):
        L, W = self.sim.L, self.sim.W
        s = np.linspace(0, L, n)
        t = np.linspace(-W / 2, W / 2, 4)
        pts = ([(x, -W / 2, 0) for x in s] + [(L, y, 0) for y in t[1:]] +
               [(x, W / 2, 0) for x in s[::-1][1:]] + [(0, y, 0) for y in t[::-1][1:-1]])
        uv, _ = self.projiziere(pts, kam)
        return uv

    # ---- Zeichnen --------------------------------------------------------
    def zeichne_flaeche(self, img, kam):
        uv = self._rand(kam)
        cv2.fillPoly(img, [ipa(uv)],
                     stimmungsfarbe(self.sim.stimmung()), cv2.LINE_AA, _SHIFT)

    def zeichne_zug(self, img, kam):
        sim = self.sim
        if not ZUG_ZEICHNEN or sim.phase == "weg":
            return
        L, W = sim.L, sim.W
        if sim.phase == "einfahrt":
            s0, s1 = L * (1 - _ease(sim.fahrt)), L
        elif sim.phase == "ausfahrt":
            s0, s1 = 0.0, L * (1 - _ease(sim.fahrt))
        else:
            s0, s1 = 0.0, L
        if s1 - s0 < 0.2:
            return
        si = sim.seite
        ti, ta = si * (W / 2 + 0.3), si * (W / 2 + 3.2)
        z0, z1 = 0.4, 3.9
        ex = self.A[:, 0] / np.linalg.norm(self.A[:, 0])
        ey = self.A[:, 1] / np.linalg.norm(self.A[:, 1])
        ez = self.n

        def poly(punkte, farbe):
            uv, z = self.projiziere(punkte, kam)
            if np.all(z > 1):
                cv2.fillPoly(img, [ipa(uv)], farbe, cv2.LINE_AA, _SHIFT)

        def wand(t, fenster, tueren):
            poly([(s0, t, z0), (s1, t, z0), (s1, t, z1), (s0, t, z1)], (205, 160, 90))
            poly([(s0, t, 2.2), (s1, t, 2.2), (s1, t, 3.1), (s0, t, 3.1)], fenster)
            if tueren:
                for st in sim.tueren():
                    a, b = st - 0.7, st + 0.7
                    if s0 <= a and b <= s1:
                        poly([(a, t, z0), (b, t, z0), (b, t, 3.2), (a, t, 3.2)], (40, 200, 240))

        offen = sim.phase == "haelt"
        flaechen = [   # (Eckpunkte, Normale im Kamerasystem, Zeichenfunktion)
            ([(s0, ta, z1), (s1, ta, z1), (s1, ti, z1), (s0, ti, z1)], ez,
             lambda q: poly(q, (150, 115, 60))),
            ([(s0, ti, z0), (s1, ti, z1)], -si * ey, lambda q: wand(ti, (70, 50, 35), offen)),
            ([(s0, ta, z0), (s1, ta, z1)], si * ey, lambda q: wand(ta, (70, 50, 35), False)),
            ([(s0, ti, z0), (s0, ta, z0), (s0, ta, z1), (s0, ti, z1)], -ex, lambda q: poly(q, (180, 140, 80))),
            ([(s1, ti, z0), (s1, ta, z0), (s1, ta, z1), (s1, ti, z1)], ex, lambda q: poly(q, (180, 140, 80))),
        ]
        sichtbar = []
        for punkte, normale, zeichne in flaechen:
            mitte = self.kamerapunkte(punkte).mean(0)
            if np.dot(normale, mitte) < 0:                 # zeigt zur Kamera
                sichtbar.append((mitte[2], punkte, zeichne))
        for _, punkte, zeichne in sorted(sichtbar, key=lambda f: -f[0]):
            zeichne(punkte)

    def zeichne_spuren_schatten(self, img, kam, spuren):
        pers = self.sim.sichtbare()
        if not pers:
            return
        k = 10
        ring = np.array([(0.28 * math.cos(2 * math.pi * j / k), 0.28 * math.sin(2 * math.pi * j / k))
                         for j in range(k)])
        pts = [(p.pos[0] + dx, p.pos[1] + dy, 0.0) for p in pers for dx, dy in ring]
        laengen = []
        if spuren:
            for p in pers:
                sp = list(p.spur) + [p.pos] if len(p.spur) else []
                laengen.append(len(sp))
                pts += [(q[0], q[1], 0.0) for q in sp]
        uv, z = self.projiziere(pts, kam)
        if np.any(z <= 1):
            return
        for i in range(len(pers)):
            cv2.fillPoly(img, [ipa(uv[i * k:(i + 1) * k])],
                         (25, 25, 25), cv2.LINE_AA, _SHIFT)
        if spuren:
            o = len(pers) * k
            for p, n in zip(pers, laengen):
                if n >= 2:
                    kurve = ipa(uv[o:o + n])
                    farbe = tuple(int(c * 0.8) for c in stimmungsfarbe(p.stimmung))
                    cv2.polylines(img, [kurve], False, farbe, 2, cv2.LINE_AA, _SHIFT)
                o += n

    def zeichne_umriss(self, img, kam):
        uv = self._rand(kam)
        cv2.polylines(img, [ipa(uv)], True,
                      (235, 235, 235), 1, cv2.LINE_AA, _SHIFT)
        if self.sim.phase in ("einfahrt", "haelt"):        # Kante zum Zug gelb
            L, W, si = self.sim.L, self.sim.W, self.sim.seite
            uv, _ = self.projiziere([(x, si * (W / 2 - 0.05), 0) for x in np.linspace(0, L, 12)], kam)
            cv2.polylines(img, [ipa(uv)], False,
                          (0, 220, 255), 2, cv2.LINE_AA, _SHIFT)

    def zeichne_personen(self, img, kam):
        pers = self.sim.sichtbare()
        if not pers:
            return
        n = len(pers)
        pts = np.zeros((n, 8, 3))
        for i, p in enumerate(pers):
            s, t = p.pos
            hg = p.groesse
            sp = math.hypot(p.vel[0], p.vel[1])
            dx, dy = (p.vel / sp) if sp > 0.15 else (1.0, 0.0)
            qx, qy = -dy, dx
            amp = 0.3 * min(1.0, sp) * math.sin(p.schritt)
            pts[i] = [(s, t, 0.0),
                      (s + dx * amp + qx * 0.1, t + dy * amp + qy * 0.1, 0.0),
                      (s - dx * amp - qx * 0.1, t - dy * amp - qy * 0.1, 0.0),
                      (s, t, 0.5 * hg), (s, t, 0.8 * hg), (s, t, 0.91 * hg),
                      (s + 0.3, t, 0.0), (s, t, hg)]
        uv, z = self.projiziere(pts.reshape(-1, 3), kam)
        uv = uv.reshape(n, 8, 2)
        uvi = ipa(uv)
        tiefe = z.reshape(n, 8)[:, 0]
        h, w = img.shape[:2]
        dunkel = (25, 25, 25)
        for i in np.argsort(-tiefe):                       # hinten zuerst
            if tiefe[i] <= 1:
                continue
            fu, fl, fr, huefte, schulter, kopf, seite, oben = uv[i]
            q = [tuple(x) for x in uvi[i].tolist()]
            q_fl, q_fr, q_huefte, q_schulter, q_kopf = q[1], q[2], q[3], q[4], q[5]
            if not (-50 < fu[0] < w + 50 and -50 < fu[1] < h + 50):
                continue
            senk = math.hypot(*(oben - fu)) / pers[i].groesse
            boden = math.hypot(*(seite - fu)) / 0.3
            ref = max(senk, 0.5 * boden)                    # Pixel pro Vorbild-Meter
            d_rumpf = max(2, int(round(ref * 0.42)))
            d_bein = max(1, int(round(ref * 0.14)))
            r_kopf = max(1.6, ref * 0.15)
            farbe = stimmungsfarbe(pers[i].stimmung)
            bein = tuple(int(c * 0.55) for c in farbe)
            hell = tuple(int(c + (255 - c) * 0.3) for c in farbe)
            for f in (q_fl, q_fr):
                cv2.line(img, q_huefte, f, dunkel, d_bein + 2, cv2.LINE_AA, _SHIFT)
                cv2.line(img, q_huefte, f, bein, d_bein, cv2.LINE_AA, _SHIFT)
            cv2.line(img, q_huefte, q_schulter, dunkel, d_rumpf + 2, cv2.LINE_AA, _SHIFT)
            cv2.line(img, q_huefte, q_schulter, farbe, d_rumpf, cv2.LINE_AA, _SHIFT)
            cv2.circle(img, q_kopf, int(round((r_kopf + 1) * _SK)), dunkel, -1, cv2.LINE_AA, _SHIFT)
            cv2.circle(img, q_kopf, int(round(r_kopf * _SK)), hell, -1, cv2.LINE_AA, _SHIFT)

    def zeichne_beschriftung(self, img, kam, skala):
        """Kleines Schild ueber dem Bahnsteiganfang (verdeckt den Bahnsteig nicht)."""
        sim = self.sim
        uv, z = self.projiziere([(0.0, 0.0, 0.0), (0.0, 0.0, 2.0 * 1.8), (sim.L, 0.0, 0.0)], kam)
        if np.any(z <= 1):
            return
        st = sim.stimmung()
        zeilen = [f"{self.name}: {sim.anzahl()} Pers., {st * 100:.0f} %", sim.statustext()]
        farben = [None, (80, 80, 255) if sim.verspaetung else (0, 220, 255)]
        anker = "ur" if uv[2][0] > uv[0][0] else "ul"      # vom Bahnsteig weg
        textkasten(img, uv[1][0], uv[1][1], zeilen, skala=skala * 0.85, anker=anker, balken=st, farben=farben)


# =============================================================================
# Anwendung
# =============================================================================

class App:
    def __init__(self, breite, hoehe, woerterbuch=None, kalibrierdatei=KALIBRIERDATEI, seed=None):
        self.w, self.h = breite, hoehe
        self.kam = Kamera(breite, hoehe, kalibrierdatei)
        ids = set(range(8)) | {i for b in BAHNSTEIGE for i in b["marker"]}
        self.erk = MarkerErkennung(woerterbuch, ids)
        rng = np.random.default_rng(seed)
        self.steige = [Bahnsteig(cfg, rng) for cfg in BAHNSTEIGE]
        self.zeit = 0.0
        self.pause = False
        self.spuren = SPUREN_ZEIGEN
        self.zeige_marker = False
        self.schilder = True
        self.andrang = 1.0
        self.verspaetung = False
        self.fps = 0.0
        self._t = None
        self.skala = max(0.45, 0.5 * breite / 1280.0)

    def verarbeite(self, bild, dt):
        jetzt = time.perf_counter()
        if self._t is not None:
            self.fps = 0.9 * self.fps + 0.1 / max(jetzt - self._t, 1e-3)
        self._t = jetzt
        self.zeit += dt

        grau = cv2.cvtColor(bild, cv2.COLOR_BGR2GRAY)
        ecken = self.erk.erkenne(grau)
        marker = {}
        for mid, c in ecken.items():
            cu = self.kam.entzerre(c)
            H = cv2.getPerspectiveTransform(MARKER_ECKEN_MM, cu.astype(np.float32))
            marker[mid] = (H, cu)
        self.kam.lerne(marker)
        self.kam.aktualisiere()
        K = self.kam.K()

        for b in self.steige:
            b.aktualisiere(marker, self.zeit)
            if not self.pause:
                b.sim.schritt(dt)
        sichtbar = [b for b in self.steige if b.sichtbar(self.zeit)]
        for b in sichtbar:
            b.pose(K)

        aus = bild.copy()
        if sichtbar:
            lage = aus.copy()
            for b in sichtbar:
                b.zeichne_flaeche(lage, self.kam)
            cv2.addWeighted(lage, 0.3, aus, 0.7, 0, aus)
            lage = aus.copy()
            for b in sichtbar:
                b.zeichne_zug(lage, self.kam)
                b.zeichne_spuren_schatten(lage, self.kam, self.spuren)
            cv2.addWeighted(lage, 0.55, aus, 0.45, 0, aus)
            for b in sichtbar:
                b.zeichne_umriss(aus, self.kam)
            for b in sichtbar:
                b.zeichne_personen(aus, self.kam)
            if self.schilder:
                for b in sichtbar:
                    b.zeichne_beschriftung(aus, self.kam, self.skala)
        if self.zeige_marker:
            for mid, c in ecken.items():
                cv2.polylines(aus, [c.astype(np.int32)], True, (255, 0, 255), 1, cv2.LINE_AA)
                cv2.putText(aus, str(mid), tuple(int(v) for v in c.mean(0)), cv2.FONT_HERSHEY_SIMPLEX,
                            0.6, (255, 0, 255), 2, cv2.LINE_AA)
        self._hud(aus)
        return aus

    def _hud(self, img):
        zeilen = [f"ArUco: {self.erk.name or 'suche Wörterbuch ...'}",
                  f"Brennweite {self.kam.f():.0f} px ({self.kam.quelle()})",
                  f"Andrang x{self.andrang:.1f}" + ("   Verspätung!" if self.verspaetung else "")
                  + ("   PAUSE" if self.pause else "")]
        farben = [None, None, (80, 80, 255) if self.verspaetung else None]
        for b in self.steige:
            s = b.status(self.zeit)
            zeilen.append(f"{b.name}: {s}   rein {len(b.sim.zu)}/min, raus {len(b.sim.ab)}/min")
            farben.append((120, 230, 120) if s == "ok" else (0, 200, 255))
        zeilen.append(f"{self.fps:.0f} FPS   Stimmung: rot = schlecht, grün = gut")
        farben.append(None)
        textkasten(img, 10, 10, zeilen, skala=self.skala, farben=farben)
        hilfe = ("1/2 Zug   V Verspätung   +/- Andrang   S Spuren   I Schilder   M Marker   "
                 ",/. Brennweite   R leeren   Leertaste Pause   Q Ende")
        textkasten(img, self.w / 2, self.h - 6, [hilfe], skala=self.skala * 0.85, anker="um")

    def taste(self, k):
        if k < 0 or k > 255:
            return
        c = chr(k).lower()
        if c.isdigit() and 1 <= int(c) <= len(self.steige):
            self.steige[int(c) - 1].sim.einfahrt()
        elif c == "v":
            self.verspaetung = not self.verspaetung
            for b in self.steige:
                b.sim.verspaetung = self.verspaetung
                if not self.verspaetung:
                    b.sim.timer = min(b.sim.timer, 4.0)
        elif c in ("+", "="):
            self.andrang = min(4.0, self.andrang * 1.3)
        elif c in ("-", "_"):
            self.andrang = max(0.15, self.andrang / 1.3)
        elif c == "s":
            self.spuren = not self.spuren
        elif c == "m":
            self.zeige_marker = not self.zeige_marker
        elif c == "i":
            self.schilder = not self.schilder
        elif c in (",", ".") and not self.kam.kalibriert:
            self.kam.f_manuell = self.kam.f() * (0.95 if c == "," else 1.05)
        elif c == " ":
            self.pause = not self.pause
        elif c == "r":
            for b in self.steige:
                b.sim.leeren()
        for b in self.steige:
            b.sim.andrang = self.andrang


def main():
    ap = argparse.ArgumentParser(description="Bahnsteig-AR mit ArUco-Markern")
    ap.add_argument("--kamera", default="0", help="Kameranummer oder Videodatei (Standard 0)")
    ap.add_argument("--breite", type=int, default=1280)
    ap.add_argument("--hoehe", type=int, default=720)
    ap.add_argument("--woerterbuch", default=WOERTERBUCH,
                    help=f"z. B. DICT_4X4_50 oder auto (Standard {WOERTERBUCH})")
    ap.add_argument("--kalibrierung", default=KALIBRIERDATEI)
    ap.add_argument("--ausgabe", default=None, help="Ergebnis zusaetzlich als Video speichern (.mp4)")
    ap.add_argument("--ohne-fenster", action="store_true")
    ap.add_argument("--max-bilder", type=int, default=0)
    ap.add_argument("--seed", type=int, default=None)
    args = ap.parse_args()

    quelle = int(args.kamera) if args.kamera.isdigit() else args.kamera
    ist_datei = not isinstance(quelle, int)
    cap = kamera_oeffnen(quelle, args.breite, args.hoehe)
    ok, bild = cap.read()
    if not ok:
        raise SystemExit(f"Keine Bilder von '{args.kamera}'. Andere Kameranummer probieren (--kamera 1).")
    h, w = bild.shape[:2]
    print(f"Bildgroesse {w} x {h}")
    woerterbuch = None if args.woerterbuch.lower() == "auto" else args.woerterbuch
    app = App(w, h, woerterbuch, args.kalibrierung, args.seed)
    fps_datei = cap.get(cv2.CAP_PROP_FPS) or 30.0

    schreiber = None
    if args.ausgabe:
        schreiber = cv2.VideoWriter(args.ausgabe, cv2.VideoWriter_fourcc(*"mp4v"),
                                    fps_datei if ist_datei else 30.0, (w, h))
    fenster = not args.ohne_fenster
    if fenster:
        cv2.namedWindow(FENSTERNAME, cv2.WINDOW_NORMAL)
        cv2.resizeWindow(FENSTERNAME, w, h)
    vollbild = False
    t_alt = time.perf_counter()
    n = 0
    while ok:
        t = time.perf_counter()
        dt = 1.0 / fps_datei if ist_datei else min(t - t_alt, 0.1)
        t_alt = t
        aus = app.verarbeite(bild, dt)
        if schreiber:
            schreiber.write(aus)
        if fenster:
            cv2.imshow(FENSTERNAME, aus)
            k = cv2.waitKey(1) & 0xFF
            if k in (ord("q"), ord("Q"), 27):
                break
            if k in (ord("f"), ord("F")):
                vollbild = not vollbild
                cv2.setWindowProperty(FENSTERNAME, cv2.WND_PROP_FULLSCREEN,
                                      cv2.WINDOW_FULLSCREEN if vollbild else cv2.WINDOW_NORMAL)
            elif k != 255:
                app.taste(k)
        n += 1
        if args.max_bilder and n >= args.max_bilder:
            break
        ok, bild = cap.read()
    cap.release()
    if schreiber:
        schreiber.release()
    cv2.destroyAllWindows()


if __name__ == "__main__":
    main()
